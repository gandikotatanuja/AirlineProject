package com.example.homeloan;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.homeloan.layer2.IncomeTable;
import com.example.homeloan.layer3.IncomeTableRepo;

@SpringBootTest
public class IncomeTableTestCase {

	@Autowired
	IncomeTableRepo iri;

	@Test
	public void testIncomeInsert() { //success
	IncomeTable it=new IncomeTable();
	
		it.setTypeOfEmp("SALARIED");
		it.setRetirementAge(65);
		it.setOrganizationType("g");
		it.setEmployerName("krishna");
		iri.addIncome(it);
			
	}


	
	@Test
	public void testIncomedelete() {//success
	//IncomeTable it=new IncomeTable();
		iri.removeIncome(54);
			
	}

	
	@Test
	public void testIncomeModify() {
	IncomeTable it=new IncomeTable();
	
	it.setTypeOfEmp("SELF-EMPLOYED");
	it.setRetirementAge(66);
	it.setOrganizationType("l");
	it.setEmployerName("Mohan");
	
	
	iri.modifyIncome(it);
	
	}
	
	
	
	
	@Test
	public void testIncomefind() {//success
	IncomeTable it=iri.findIncome(203);
	System.out.println(it.getIncomeId());
	System.out.println(it.getTypeOfEmp());
	System.out.println(it.getOrganizationType());
	System.out.println(it.getRetirementAge());
	System.out.println(it.getUserTable());
	
	}
	
	
	
	@Test
	public void testIncomefindAll() { //success
		List<IncomeTable> ilist=iri.findIncomes();		
		IncomeTable it=new IncomeTable();
		for(IncomeTable i:ilist) {
		System.out.println(i.getIncomeId());
		System.out.println(i.getTypeOfEmp());
		System.out.println(i.getOrganizationType());
		System.out.println(i.getRetirementAge());
		System.out.println(i.getUserTable());
		
		
		}
	}
	
}
