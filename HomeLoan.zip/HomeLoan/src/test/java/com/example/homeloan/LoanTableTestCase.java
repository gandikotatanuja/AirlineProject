package com.example.homeloan;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.homeloan.layer2.LoanTable;
import com.example.homeloan.layer3.LoanTableRepo;

@SpringBootTest
public class LoanTableTestCase {

	@Autowired
	LoanTableRepo lri;
	

	@Test
	public void testInsertNewLoan() {//success
		LoanTable loan = new LoanTable();
		loan.setLoanId(301);
		loan.setMaxLoan(200000);
		loan.setInterestRate(11.25f);
		loan.setTenure(120);
		loan.setLoanAmount(15000000);
	
		lri.addLoan(loan);
	}
	@Test
	public void testLoanModify() {
		LoanTable loan = new LoanTable();
		loan.setLoanId(301);
		loan.setMaxLoan(200000);
		loan.setInterestRate(12.25f);
		loan.setTenure(120);
		loan.setLoanAmount(15000000);
		lri.modifyLoan(loan);
		
	}
		

	@Test
	public void testRemoveLoan() {//success
		lri.removeLoan(301);
		
	}

	@Test
	public void testFindLoan() {//success
		LoanTable l=lri.findLoan(303);
		System.out.println(l.getLoanId());
		System.out.println(l.getMaxLoan());
		System.out.println(l.getInterestRate());
		System.out.println(l.getTenure());
		
		System.out.println("-----------------");
		
	}
	
	
	@Test
	public void testFindAllloan() {//success
		List<LoanTable> loanlist = lri.findLoans();
		for (LoanTable l: loanlist) {
			System.out.println(l.getLoanId());
			System.out.println(l.getMaxLoan());
			System.out.println(l.getInterestRate());
			System.out.println(l.getTenure());
			
			System.out.println("-----------------");
		}
	}
	
	
}
