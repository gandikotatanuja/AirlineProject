package com.example.homeloan;

import java.sql.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.homeloan.layer2.UserTable;
import com.example.homeloan.layer3.UserTableRepo;

@SpringBootTest
 class UserTableTest {
	
	@Autowired
	UserTableRepo uri;
	
	@Test
	public void testInsertNewUser() {  //succes
		UserTable user = new UserTable();
		
		user.setFname("radha");
		user.setMname("krishna");
		user.setLname("g");
		user.setMailid("ri@gmail.com");
		user.setPassword("123@asg");
		user.setConfirmPassword("123@asg");
		user.setAddress("ap");
		user.setPhoneno((long) 1254126398);
		 String str2="1996-08-15";
		 Date date2=Date.valueOf(str2);
		user.setDob(date2);
		user.setGender("male");
		user.setNationality("indian");
		user.setAdharNo(1254126398);
		user.setPanNo("clap1234");
		uri.addUser(user);
			
	}
	@Test
	public void testModify() {
		UserTable user = new UserTable();

		user.setFname("radha");
		user.setMname("krishna");
		user.setLname("g");
		user.setMailid("r@gmail.com");
		user.setPassword("1234@asg");
		user.setConfirmPassword("1234@asg");
		user.setAddress("ap");
		user.setPhoneno((long) 1254126398);
		 String str2="1996-08-15";
		 Date date2=Date.valueOf(str2);
		user.setDob(date2);
		user.setGender("male");
		user.setNationality("indian");
		user.setAdharNo(1254126398);
		user.setPanNo("clap1235");
		uri.modifyUser(user);
		
		
	}
	@Test
	public void testRemove() {//success
		
		uri.removeUser(44);
		
		
		
	}
	@Test
	public void testUserFind() { //success

	   UserTable d=uri.findUser(105);
	   System.out.println(d.getUserId());
		System.out.println(d.getFname());
		System.out.println(d.getMname());
		System.out.println(d.getLname());
		System.out.println(d.getMailid());
		System.out.println(d.getPassword());
		System.out.println(d.getConfirmPassword());
		System.out.println(d.getAddress());
		System.out.println(d.getDob());
		System.out.println(d.getGender());
		System.out.println(d.getPhoneno());
		System.out.println(d.getNationality());
		System.out.println(d.getAdharNo());
		System.out.println(d.getPanNo());
		System.out.println("-----------------");

	}
	@Test
	public void testFindAll() {//success
		
		List<UserTable> userlist = uri.findUsers();
		for (UserTable d: userlist) {
			System.out.println(d.getUserId());
			System.out.println(d.getFname());
			System.out.println(d.getMname());
			System.out.println(d.getLname());
			System.out.println(d.getMailid());
			System.out.println(d.getPassword());
			System.out.println(d.getConfirmPassword());
			System.out.println(d.getAddress());
			System.out.println(d.getDob());
			System.out.println(d.getGender());
			System.out.println(d.getPhoneno());
			System.out.println(d.getNationality());
			System.out.println(d.getAdharNo());
			System.out.println(d.getPanNo());
			System.out.println("-----------------");
		}
	
	}
}
