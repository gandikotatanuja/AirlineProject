package com.example.homeloan;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.homeloan.layer2.ProTable;
import com.example.homeloan.layer3.ProTableRepo;

@SpringBootTest
public class ProTableTest {
	@Autowired
	ProTableRepo pri;
	@Test
	public void testInsertNewPro() {
		ProTable pro = new ProTable();
		
		pro.setPropertyLoc("ViZAG");
		pro.setPropertyName("KRISHNA");
		pro.setPropertyType("Plot");
		pro.setEstimatedAmt(1600000);
		//pro.setIncomeTable(201);
		
		pri.addProTable(pro);
	}
	@Test
	public void testModifyPro() {
		ProTable pro = new ProTable();
	
		pro.setPropertyLoc("ViZAG");
		pro.setPropertyName("RadhaKrishna");
		pro.setPropertyType("Plot");
		pro.setEstimatedAmt(1600000);
		pri.addProTable(pro);

	}
	@Test
	public void testRemovePro() {//sucess
		pri.removeProTable(601);
		
	}
	@Test
	public void testFindPro() {//sucess
		ProTable p=pri.findProTable(603);
		System.out.println(p.getProId());
		System.out.println(p.getPropertyLoc());
		System.out.println(p.getPropertyName());
		System.out.println(p.getPropertyType());
		System.out.println(p.getEstimatedAmt());
		System.out.println(p.getIncomeTable());
		
		System.out.println("-----------------");
	}
	@Test
	public void testFindAllPro() { //success
		List<ProTable> prolist = pri.findProTables();
		for (ProTable p: prolist) {
			System.out.println(p.getProId());
			System.out.println(p.getPropertyLoc());
			System.out.println(p.getPropertyName());
			System.out.println(p.getPropertyType());
			System.out.println(p.getEstimatedAmt());
			System.out.println(p.getIncomeTable());
			
			System.out.println("-----------------");
		}
	}

}
