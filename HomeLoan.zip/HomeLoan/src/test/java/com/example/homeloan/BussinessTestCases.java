package com.example.homeloan;

import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.homeloan.layer2.DocTable;
import com.example.homeloan.layer2.IncomeTable;
import com.example.homeloan.layer2.LoanTrackerTable;
import com.example.homeloan.layer2.ProTable;
import com.example.homeloan.layer3.DocTableRepo;
import com.example.homeloan.layer3.IncomeTableRepo;
import com.example.homeloan.layer3.LoanTrackerTableRepo;
import com.example.homeloan.layer3.ProTableRepo;


@SpringBootTest
public class BussinessTestCases {
	@Autowired
	DocTableRepo docRepo;
	@Autowired
	LoanTrackerTableRepo lRepo;
	@Autowired
	IncomeTableRepo iRepo;
	@Autowired
	ProTableRepo pRepo;
	@Test
	void DocByUserId() {
		Set<DocTable> docSet = docRepo.findDocByUserId(101);
		for (DocTable d: docSet) {
			System.out.println(d.getDocId());
			System.out.println(d.getPanCard());
			System.out.println(d.getVoterId());
			System.out.println(d.getSalaryslip());
			System.out.println(d.getLoa());
			System.out.println(d.getNoc());
			System.out.println(d.getAgreement());
			System.out.println("-----------------");
		}
	}
		@Test
		void LoanTrackerByUserId() {
			Set<LoanTrackerTable> lSet = lRepo.findLoanAppIdByUserId(101);
			for (LoanTrackerTable d: lSet) {
				System.out.println(d.getFinalId());
				System.out.println(d.getAccNo());
				System.out.println(d.getLoanAppId());
				System.out.println(d.getLoanapprovaldate());
				System.out.println("-----------------");
			}
		}
		@Test
		void IncomeByUserId() {
			Set<IncomeTable> iSet = iRepo.findIncomeByUserId(101);
			for (IncomeTable it: iSet) {
				System.out.println(it.getIncomeId());
				System.out.println(it.getTypeOfEmp());
				System.out.println(it.getOrganizationType());
				System.out.println(it.getRetirementAge());
				System.out.println(it.getUserTable());
				System.out.println("-----------------");
			}
		}
		@Test
		void PropertyByUserId() {
			Set<ProTable> iSet = pRepo.findProByUserId(101);
			for (ProTable p: iSet) {
				System.out.println(p.getProId());
				System.out.println(p.getPropertyLoc());
				System.out.println(p.getPropertyName());
				System.out.println(p.getPropertyType());
				System.out.println(p.getEstimatedAmt());
				System.out.println(p.getIncomeTable());
				System.out.println("-----------------");
			}
		}
		
		
		
		
		
}