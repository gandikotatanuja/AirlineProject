package com.example.homeloan;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.homeloan.layer2.DocTable;
import com.example.homeloan.layer3.DocTableRepo;

@SpringBootTest
public class DocTableTestCase {


	@Autowired
	DocTableRepo dri1;
	
	@Test
	public void testInsertNewDoc() {//success
		DocTable doc = new DocTable();
		
		doc.setPanCard("Uploaded");
		doc.setVoterId("Submitted");
		doc.setSalaryslip("Uploaded");
		doc.setLoa("Completed");
		doc.setNoc("Submitted");
		doc.setAgreement("Submitted");
		
		dri1.adddoc(doc);
	}
	@Test
	public void testModifyDoc() {
		DocTable doc = new DocTable();
		
		doc.setPanCard("Uploaded");
		doc.setVoterId("notsubmitted");
		doc.setSalaryslip("Uploaded");
		doc.setLoa("Completed");
		doc.setNoc("Submitted");
		doc.setAgreement("Not Submitted");
		
		dri1.adddoc(doc);
		
	}
	@Test
	public void testRemoveDoc() {//success
		dri1.removeDocTable(59);
		
	}
	@Test
	public void testFindDoc() {//success
		DocTable d=dri1.findDocTable(703);
		System.out.println(d.getDocId());
		System.out.println(d.getPanCard());
		System.out.println(d.getVoterId());
		System.out.println(d.getSalaryslip());
		System.out.println(d.getLoa());
		System.out.println(d.getNoc());
		System.out.println(d.getAgreement());
		System.out.println("-----------------");
	
	}
	@Test
	public void testFindAllDoc() {//success
		List<DocTable> doclist = dri1.findDocTables();
		for (DocTable d: doclist) {
			System.out.println(d.getDocId());
			System.out.println(d.getPanCard());
			System.out.println(d.getVoterId());
			System.out.println(d.getSalaryslip());
			System.out.println(d.getLoa());
			System.out.println(d.getNoc());
			System.out.println(d.getAgreement());
			System.out.println("-----------------");
		}
		
	}
}
