package com.example.homeloan;

import java.sql.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.homeloan.layer2.DocTable;
import com.example.homeloan.layer2.IncomeTable;
import com.example.homeloan.layer2.LoanTable;
import com.example.homeloan.layer2.LoanTrackerTable;
import com.example.homeloan.layer2.ProTable;
import com.example.homeloan.layer2.UserTable;
import com.example.homeloan.layer3.DocTableRepo;
import com.example.homeloan.layer3.IncomeTableRepo;
import com.example.homeloan.layer3.LoanTableRepo;
import com.example.homeloan.layer3.LoanTrackerTableRepo;
import com.example.homeloan.layer3.ProTableRepo;
import com.example.homeloan.layer3.UserTableRepo;

@SpringBootTest
class HomeLoanApplicationTests {
	
	@Autowired
	UserTableRepo uri;
	
	@Autowired
	LoanTableRepo lri;
	
	@Autowired
	IncomeTableRepo iri;
	
	@Autowired
	DocTableRepo dri1;
	
	@Autowired
	ProTableRepo pri;
	
	@Autowired
	LoanTrackerTableRepo ltr;
	
	
	@Test
	public void testInsertNewUser() {  //succes
		UserTable user = new UserTable();
		
		user.setFname("radha");
		user.setMname("krishna");
		user.setLname("g");
		user.setMailid("ri@gmail.com");
		user.setPassword("123@asg");
		user.setConfirmPassword("123@asg");
		user.setAddress("ap");
		user.setPhoneno((long) 1254126398);
		 String str2="1996-08-15";
		 Date date2=Date.valueOf(str2);
		user.setDob(date2);
		user.setGender("male");
		user.setNationality("indian");
		user.setAdharNo(1254126398);
		user.setPanNo("clap1234");
		uri.addUser(user);
			
	}
	@Test
	public void testModify() {
		UserTable user = new UserTable();

		user.setFname("radha");
		user.setMname("krishna");
		user.setLname("g");
		user.setMailid("r@gmail.com");
		user.setPassword("1234@asg");
		user.setConfirmPassword("1234@asg");
		user.setAddress("ap");
		user.setPhoneno((long) 1254126398);
		 String str2="1996-08-15";
		 Date date2=Date.valueOf(str2);
		user.setDob(date2);
		user.setGender("male");
		user.setNationality("indian");
		user.setAdharNo(1254126398);
		user.setPanNo("clap1235");
		uri.modifyUser(user);
		
		
	}
	@Test
	public void testRemove() {//success
		
		uri.removeUser(44);
		
		
		
	}
	@Test
	public void testUserFind() { //success

	   UserTable d=uri.findUser(105);
	   System.out.println(d.getUserId());
		System.out.println(d.getFname());
		System.out.println(d.getMname());
		System.out.println(d.getLname());
		System.out.println(d.getMailid());
		System.out.println(d.getPassword());
		System.out.println(d.getConfirmPassword());
		System.out.println(d.getAddress());
		System.out.println(d.getDob());
		System.out.println(d.getGender());
		System.out.println(d.getPhoneno());
		System.out.println(d.getNationality());
		System.out.println(d.getAdharNo());
		System.out.println(d.getPanNo());
		System.out.println("-----------------");

	}
	@Test
	public void testFindAll() {//success
		
		List<UserTable> userlist = uri.findUsers();
		for (UserTable d: userlist) {
			System.out.println(d.getUserId());
			System.out.println(d.getFname());
			System.out.println(d.getMname());
			System.out.println(d.getLname());
			System.out.println(d.getMailid());
			System.out.println(d.getPassword());
			System.out.println(d.getConfirmPassword());
			System.out.println(d.getAddress());
			System.out.println(d.getDob());
			System.out.println(d.getGender());
			System.out.println(d.getPhoneno());
			System.out.println(d.getNationality());
			System.out.println(d.getAdharNo());
			System.out.println(d.getPanNo());
			System.out.println("-----------------");
		}
	
		
	}
	
	
	@Test
	public void testInsertNewLoan() {//success
		LoanTable loan = new LoanTable();
		loan.setLoanId(301);
		loan.setMaxLoan(200000);
		loan.setInterestRate(11.25f);
		loan.setTenure(120);
		loan.setLoanAmount(15000000);
	
		lri.addLoan(loan);
	}
	@Test
	public void testModify1() {
		LoanTable loan = new LoanTable();
		loan.setLoanId(301);
		loan.setMaxLoan(200000);
		loan.setInterestRate(12.25f);
		loan.setTenure(120);
		loan.setLoanAmount(15000000);
		lri.modifyLoan(loan);
		
	}
		

	@Test
	public void testRemoveLoan() {//success
		lri.removeLoan(301);
		
	}

	@Test
	public void testFindLoan() {//success
		LoanTable l=lri.findLoan(303);
		System.out.println(l.getLoanId());
		System.out.println(l.getMaxLoan());
		System.out.println(l.getInterestRate());
		System.out.println(l.getTenure());
		
		System.out.println("-----------------");
		
	}
	
	
	@Test
	public void testFindAllloan() {//success
		List<LoanTable> loanlist = lri.findLoans();
		for (LoanTable l: loanlist) {
			System.out.println(l.getLoanId());
			System.out.println(l.getMaxLoan());
			System.out.println(l.getInterestRate());
			System.out.println(l.getTenure());
			System.out.println(l.getProTable());
			System.out.println("-----------------");
		}
	}
	
	
	@Test
	public void testIncomeInsert() { //success
	IncomeTable it=new IncomeTable();
	
		it.setTypeOfEmp("SALARIED");
		it.setRetirementAge(65);
		it.setOrganizationType("g");
		it.setEmployerName("krishna");
		iri.addIncome(it);
			
	}


	
	@Test
	public void testIncomedelete() {//success
	IncomeTable it=new IncomeTable();
		iri.removeIncome(54);
			
	}

	
	@Test
	public void testIncomeModify() {
	IncomeTable it=new IncomeTable();
	
	it.setTypeOfEmp("SELF-EMPLOYED");
	it.setRetirementAge(66);
	it.setOrganizationType("l");
	it.setEmployerName("Mohan");
	
	
	iri.modifyIncome(it);
	
	}
	
	
	
	
	@Test
	public void testIncomefind() {//success
	IncomeTable it=iri.findIncome(203);
	System.out.println(it.getIncomeId());
	System.out.println(it.getTypeOfEmp());
	System.out.println(it.getOrganizationType());
	System.out.println(it.getRetirementAge());
	System.out.println(it.getUserTable());
	
	}
	
	
	
	@Test
	public void testIncomefindAll() { //success
		List<IncomeTable> ilist=iri.findIncomes();		
		IncomeTable it=new IncomeTable();
		for(IncomeTable i:ilist) {
		System.out.println(i.getIncomeId());
		System.out.println(i.getTypeOfEmp());
		System.out.println(i.getOrganizationType());
		System.out.println(i.getRetirementAge());
		System.out.println(i.getUserTable());
		
		
		}

	
	}
	
	
	@Test
	public void testInsertNewDoc() {//success
		DocTable doc = new DocTable();
		
		doc.setPanCard("Uploaded");
		doc.setVoterId("Submitted");
		doc.setSalaryslip("Uploaded");
		doc.setLoa("Completed");
		doc.setNoc("Submitted");
		doc.setAgreement("Submitted");
		
		dri1.adddoc(doc);
	}
	@Test
	public void testModifyDoc() {
		DocTable doc = new DocTable();
		
		doc.setPanCard("Uploaded");
		doc.setVoterId("notsubmitted");
		doc.setSalaryslip("Uploaded");
		doc.setLoa("Completed");
		doc.setNoc("Submitted");
		doc.setAgreement("Not Submitted");
		
		dri1.adddoc(doc);
		
	}
	@Test
	public void testRemoveDoc() {//success
		dri1.removeDocTable(59);
		
	}
	@Test
	public void testFindDoc() {//success
		DocTable d=dri1.findDocTable(703);
		System.out.println(d.getDocId());
		System.out.println(d.getPanCard());
		System.out.println(d.getVoterId());
		System.out.println(d.getSalaryslip());
		System.out.println(d.getLoa());
		System.out.println(d.getNoc());
		System.out.println(d.getAgreement());
		System.out.println("-----------------");
	
	}
	@Test
	public void testFindAllDoc() {//success
		List<DocTable> doclist = dri1.findDocTables();
		for (DocTable d: doclist) {
			System.out.println(d.getDocId());
			System.out.println(d.getPanCard());
			System.out.println(d.getVoterId());
			System.out.println(d.getSalaryslip());
			System.out.println(d.getLoa());
			System.out.println(d.getNoc());
			System.out.println(d.getAgreement());
			System.out.println("-----------------");
		}
		
	
}
	
	
	@Test
	public void testInsertNewPro() {
		ProTable pro = new ProTable();
		
		pro.setPropertyLoc("ViZAG");
		pro.setPropertyName("KRISHNA");
		pro.setPropertyType("Plot");
		pro.setEstimatedAmt(1600000);
		//pro.setIncomeTable(201);
		
		pri.addProTable(pro);
	}
	@Test
	public void testModifyPro() {
		ProTable pro = new ProTable();
	
		pro.setPropertyLoc("ViZAG");
		pro.setPropertyName("RadhaKrishna");
		pro.setPropertyType("Plot");
		pro.setEstimatedAmt(1600000);
		pri.addProTable(pro);

	}
	@Test
	public void testRemovePro() {//sucess
		pri.removeProTable(601);
		
	}
	@Test
	public void testFindPro() {//sucess
		ProTable p=pri.findProTable(603);
		System.out.println(p.getProId());
		System.out.println(p.getPropertyLoc());
		System.out.println(p.getPropertyName());
		System.out.println(p.getPropertyType());
		System.out.println(p.getEstimatedAmt());
		System.out.println(p.getIncomeTable());
		
		System.out.println("-----------------");
	}
	@Test
	public void testFindAllPro() { //success
		List<ProTable> prolist = pri.findProTables();
		for (ProTable p: prolist) {
			System.out.println(p.getProId());
			System.out.println(p.getPropertyLoc());
			System.out.println(p.getPropertyName());
			System.out.println(p.getPropertyType());
			System.out.println(p.getEstimatedAmt());
			System.out.println(p.getIncomeTable());
			
			System.out.println("-----------------");
		}
	}
	

	@Test
	public void testLoanTrackerInsert() {//success
	LoanTrackerTable lt=new LoanTrackerTable();
	String str2="1996-08-15";
	 Date date2=Date.valueOf(str2);
	lt.setLoanapprovaldate(date2);
	lt.setAccNo(1524789365);
	lt.setLoanAppId(10006);
	ltr.addLoanTracker(lt);
	
	}
	
	@Test
	public void testLoanTrackerDelete() {//success
	ltr.removeLoanTracker(61);
	}
	@Test
	public void testLoanTrackerModify() {
	LoanTrackerTable lt=new LoanTrackerTable();
	//lt.setFinalId(802);
	String st="02-Mar-2020";
	 Date date2=Date.valueOf(st);
	lt.setLoanapprovaldate(date2);
	lt.setLoanAppId(10005);
	lt.setAccNo(952147823);
	
	ltr.modifyLoanTracker(lt);
	}
	
	@Test
	public void testLoanTrackerFindAll() {//success
	LoanTrackerTable lt=new LoanTrackerTable();
	List<LoanTrackerTable> llist=ltr.findLoanTrackers();		
	
	for(LoanTrackerTable l:llist) {
		System.out.println(l.getAccNo());
		System.out.println(l.getFinalId());
		System.out.println(l.getLoanAppId());
		System.out.println(l.getLoanapprovaldate());
		System.out.println(l.getDocTable());
		
	}
	}
}


