package com.example.homeloan;

import java.sql.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.homeloan.layer2.LoanTrackerTable;
import com.example.homeloan.layer3.LoanTrackerTableRepo;

@SpringBootTest
public class LoanTrackerTableTestCase {
	@Autowired
	LoanTrackerTableRepo ltr;
	
	@Test
	public void testLoanTrackerInsert() {//success
	LoanTrackerTable lt=new LoanTrackerTable();
	String str2="1996-08-15";
	 Date date2=Date.valueOf(str2);
	lt.setLoanapprovaldate(date2);
	lt.setAccNo(1524789365);
	lt.setLoanAppId(10006);
	ltr.addLoanTracker(lt);
	
	}
	
	@Test
	public void testLoanTrackerDelete() {//success
	ltr.removeLoanTracker(61);
	}
	@Test
	public void testLoanTrackerModify() {
	LoanTrackerTable lt=new LoanTrackerTable();
	//lt.setFinalId(802);
	String st="02-Mar-2020";
	 Date date2=Date.valueOf(st);
	lt.setLoanapprovaldate(date2);
	lt.setLoanAppId(10005);
	lt.setAccNo(952147823);
	
	ltr.modifyLoanTracker(lt);
	}
	
	@Test
	public void testLoanTrackerFindAll() {//success
	//LoanTrackerTable lt=new LoanTrackerTable();
	List<LoanTrackerTable> llist=ltr.findLoanTrackers();		
	
	for(LoanTrackerTable l:llist) {
		System.out.println(l.getAccNo());
		System.out.println(l.getFinalId());
		System.out.println(l.getLoanAppId());
		System.out.println(l.getLoanapprovaldate());
		System.out.println(l.getDocTable());
		
	}
	}
	
	@Test
	public void testLoanTrackerFind() {//sucess
		LoanTrackerTable lt=ltr.findLoanTracker(802);
		System.out.println(lt.getLoanapprovaldate());
		System.out.println(lt.getLoanAppId());
		System.out.println(lt.getAccNo());
		System.out.println(lt.getDocTable());
		
		
		System.out.println("-----------------");
	}
	
}

