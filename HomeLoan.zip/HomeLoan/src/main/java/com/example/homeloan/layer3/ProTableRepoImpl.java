package com.example.homeloan.layer3;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.homeloan.layer2.LoanTrackerTable;
import com.example.homeloan.layer2.ProTable;

@Repository
public class ProTableRepoImpl implements ProTableRepo {

	@PersistenceContext
	 EntityManager entityManager;
	
	@Transactional
	public void addProTable(ProTable pRef) {
		entityManager.persist(pRef);

	}
	@Transactional
	public ProTable findProTable(int pno) {
		System.out.println("Department repo....NO scope of bussiness logic here...");
		return entityManager.find(ProTable.class,pno);
		
	}
	@Transactional
	public List<ProTable> findProTables() {
		List<ProTable> proList;
		proList = new ArrayList<ProTable>();
		
			String queryString = "from ProTable";
			Query query = entityManager.createQuery(queryString);
			proList = query.getResultList();
			
		
		return proList;
	}
	@Transactional
	public void modifyProTable(ProTable pRef) {
		entityManager.merge(pRef);

	}
	@Transactional
	public void removeProTable(int pno) {
		ProTable pTemp = entityManager.find(ProTable.class,pno);
		entityManager.remove(pTemp);
			
		
	}
	@Transactional
	public Set<ProTable> findProByUserId(int i) {
		
	Set<ProTable> docSet;
			
			//Query query = entityManager.createQuery("from loanTrackerTable d where DocTable e=(from DocTable e where rep_id =:myno)",LoanTrackerTable.class).setParameter("myno", i);
			//empSet = (Set<Employee2>) query.getResultList().stream().collect(Collectors.toSet());
			Query query = entityManager.createNativeQuery("select * from pro_table where income_id=(select income_id from income_table where user_id=101)",ProTable.class);

			docSet = new HashSet(query.getResultList());
				
			
		return docSet;
		}
	}
