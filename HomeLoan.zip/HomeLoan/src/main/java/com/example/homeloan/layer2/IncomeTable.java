package com.example.homeloan.layer2;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the INCOME_TABLE database table.
 * 
 */
@Entity
@Table(name="INCOME_TABLE")
@NamedQuery(name="IncomeTable.findAll", query="SELECT i FROM IncomeTable i")
public class IncomeTable implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name="INCOME_ID")
	private int incomeId;

	@Column(name="EMPLOYER_NAME")
	private String employerName;

	@Column(name="ORGANIZATION_TYPE")
	private String organizationType;

	@Column(name="RETIREMENT_AGE")
	private int retirementAge;

	@Column(name="TYPE_OF_EMP")
	private String typeOfEmp;

	//bi-directional many-to-one association to UserTable
	@ManyToOne
	@JoinColumn(name="USER_ID")
	private UserTable userTable;

	//bi-directional many-to-one association to ProTable
	@OneToMany(mappedBy="incomeTable", fetch=FetchType.EAGER,cascade = CascadeType.ALL)
	private Set<ProTable> proTables;

	public IncomeTable() {
	}

	public int getIncomeId() {
		return incomeId;
	}

	public void setIncomeId(int incomeId) {
		this.incomeId = incomeId;
	}

	public String getEmployerName() {
		return employerName;
	}

	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}

	public String getOrganizationType() {
		return organizationType;
	}

	public void setOrganizationType(String organizationType) {
		this.organizationType = organizationType;
	}

	public int getRetirementAge() {
		return retirementAge;
	}

	public void setRetirementAge(int retirementAge) {
		this.retirementAge = retirementAge;
	}

	public String getTypeOfEmp() {
		return typeOfEmp;
	}

	public void setTypeOfEmp(String typeOfEmp) {
		this.typeOfEmp = typeOfEmp;
	}

	public UserTable getUserTable() {
		return userTable;
	}

	public void setUserTable(UserTable userTable) {
		this.userTable = userTable;
	}

	public Set<ProTable> getProTables() {
		return proTables;
	}

	public void setProTables(Set<ProTable> proTables) {
		this.proTables = proTables;
	}
	public ProTable addProTable(ProTable proTable) {
		getProTables().add(proTable);
		proTable.setIncomeTable(this);

		return proTable;
	}

	public ProTable removeProTable(ProTable proTable) {
		getProTables().remove(proTable);
		proTable.setIncomeTable(null);

		return proTable;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
}