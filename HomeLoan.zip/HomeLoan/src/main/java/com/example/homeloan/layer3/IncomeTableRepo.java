package com.example.homeloan.layer3;
import java.util.List;
import java.util.Set;

import com.example.homeloan.layer2.*;

public interface IncomeTableRepo {


	void addIncome(IncomeTable iref);		//	C - add - insert
	IncomeTable findIncome(int ino);			//  R - find - select
	List<IncomeTable> findIncomes();			//  R - find - select all
	void modifyIncome(IncomeTable iref);		//  U - modify - update
	void removeIncome(int dno);		//  D
	Set<IncomeTable> findIncomeByUserId(int i);
}
