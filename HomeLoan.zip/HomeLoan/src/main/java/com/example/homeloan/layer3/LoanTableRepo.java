package com.example.homeloan.layer3;

import java.util.List;

import com.example.homeloan.layer2.LoanTable;


public interface LoanTableRepo{

	void addLoan(LoanTable lRef);		//	C - add - insert
	LoanTable findLoan(int lno);			//  R - find - select
	List<LoanTable> findLoans();			//  R - find - select all
	void modifyLoan(LoanTable lRef);		//  U - modify - update
	void removeLoan(int lno);     //  D - remove - delete
}