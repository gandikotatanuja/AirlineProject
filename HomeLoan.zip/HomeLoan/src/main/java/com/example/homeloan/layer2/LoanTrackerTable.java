package com.example.homeloan.layer2;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the LOANTRACKER_TABLE database table.
 * 
 */
@Entity
@Table(name="LOANTRACKER_TABLE")
@NamedQuery(name="LoanTrackerTable.findAll", query="SELECT l FROM LoanTrackerTable l")
public class LoanTrackerTable implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name="FINAL_ID")
	private int finalId;

	@Column(name="ACC_NO")
	private double accNo;

	@Column(name="LOANAPP_ID")
	private int loanAppId;

	@Temporal(TemporalType.DATE)
	private Date loanapprovaldate;

	//bi-directional one-to-one association to DocTable
	@OneToOne(mappedBy="loanTrackerTable",cascade = CascadeType.ALL, fetch=FetchType.EAGER)
	private DocTable docTable;

	public LoanTrackerTable() {
		System.out.println("loantrackertable const() called...");
	}

	public int getFinalId() {
		return finalId;
	}

	public void setFinalId(int finalId) {
		this.finalId = finalId;
	}

	public double getAccNo() {
		return accNo;
	}

	public void setAccNo(double accNo) {
		this.accNo = accNo;
	}

	public int getLoanAppId() {
		return loanAppId;
	}

	public void setLoanAppId(int loanAppId) {
		this.loanAppId = loanAppId;
	}

	public Date getLoanapprovaldate() {
		return loanapprovaldate;
	}

	public void setLoanapprovaldate(Date loanapprovaldate) {
		this.loanapprovaldate = loanapprovaldate;
	}

	public DocTable getDocTable() {
		return docTable;
	}

	public void setDocTable(DocTable docTable) {
		this.docTable = docTable;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
	
}