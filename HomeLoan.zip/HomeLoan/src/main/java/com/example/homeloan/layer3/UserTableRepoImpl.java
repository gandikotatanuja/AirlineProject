package com.example.homeloan.layer3;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.example.homeloan.layer2.UserTable;

@Repository
public class UserTableRepoImpl implements UserTableRepo {

	@PersistenceContext
	 EntityManager entityManager;
	
	@Transactional
	public void addUser(UserTable uRef) {
		entityManager.persist(uRef);

	}
	@Transactional
	public UserTable findUser(int uno) {
		System.out.println("Department repo....NO scope of bussiness logic here...");
		return entityManager.find(UserTable.class,uno);
		
	}
	@Transactional
	public List<UserTable> findUsers() {
		List<UserTable> userList;
		userList = new ArrayList<UserTable>();
		
			String queryString = "from UserTable";
			Query query = entityManager.createQuery(queryString);
			userList = query.getResultList();
			
		
		return userList;
	}
	/*@Transactional
	public List<UserTable> findJpql3Departments() {
		List<UserTable> userList;
		userList = new ArrayList<UserTable>();
		
			
			Query query = entityManager.createNamedQuery("deptMUMBAI",UserTable.class).setParameter("mylocation", "MUMBAI");
			userList = query.getResultList();
			
		
		return userList;
		
		
	}*/
	@Transactional
	public void modifyUser(UserTable uRef) {
		entityManager.merge(uRef);

	}
	@Transactional
	public void removeUser(int uno) {
		UserTable dTemp = entityManager.find(UserTable.class,uno);
		entityManager.remove(dTemp);
			
		
	}

}
