package com.example.homeloan.layer3;

import java.util.List;
import java.util.Set;

import com.example.homeloan.layer2.ProTable;



 public interface ProTableRepo {
	 void addProTable(ProTable pRef);
		ProTable findProTable(int pno);			
		List<ProTable> findProTables();			
		void modifyProTable(ProTable pRef);
		void removeProTable(int pno);
		Set<ProTable> findProByUserId(int i); 
}