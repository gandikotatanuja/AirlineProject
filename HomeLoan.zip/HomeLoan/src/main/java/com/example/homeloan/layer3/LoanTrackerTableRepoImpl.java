
	package com.example.homeloan.layer3;

	import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
	import javax.persistence.PersistenceContext;
	import javax.persistence.Query;

	import org.springframework.stereotype.Repository;
	import org.springframework.transaction.annotation.Transactional;

import com.example.homeloan.layer2.DocTable;
import com.example.homeloan.layer2.LoanTrackerTable;

	@Repository
	public class LoanTrackerTableRepoImpl implements LoanTrackerTableRepo {

		@PersistenceContext
		 EntityManager entityManager;
		
		@Transactional
		public void addLoanTracker(LoanTrackerTable lRef) {
			entityManager.persist(lRef);

		}

		@Transactional
		public LoanTrackerTable findLoanTracker(int lno) {
			System.out.println("LoanTracker repo....NO scope of bussiness logic here...");
			return entityManager.find(LoanTrackerTable.class,lno);
		}

		@Transactional
		public List<LoanTrackerTable> findLoanTrackers() {
			List<LoanTrackerTable> LoantrackerList;
			LoantrackerList = new ArrayList<LoanTrackerTable>();
			
				String queryString = "from LoanTrackerTable";
				Query query = entityManager.createQuery(queryString);
				LoantrackerList = query.getResultList();
				
			
			return LoantrackerList;
		}

		@Transactional
		public void modifyLoanTracker(LoanTrackerTable lRef) {
	     	entityManager.merge(lRef);

		}

		@Transactional
		public void removeLoanTracker(int lno) {
			LoanTrackerTable lTemp = entityManager.find(LoanTrackerTable.class,lno);
			entityManager.remove(lTemp);
		}

		@Transactional
		public Set<LoanTrackerTable> findLoanAppIdByUserId(int i) {
			Set<LoanTrackerTable> docSet;
			
			//Query query = entityManager.createQuery("from loanTrackerTable d where DocTable e=(from DocTable e where rep_id =:myno)",LoanTrackerTable.class).setParameter("myno", i);
			//empSet = (Set<Employee2>) query.getResultList().stream().collect(Collectors.toSet());
			Query query = entityManager.createNativeQuery("select * from loantracker_table where doc_id=(select doc_id from doc_table where rep_id=101)",LoanTrackerTable.class);

			docSet = new HashSet(query.getResultList());
				
			
		return docSet;
		}

	}

