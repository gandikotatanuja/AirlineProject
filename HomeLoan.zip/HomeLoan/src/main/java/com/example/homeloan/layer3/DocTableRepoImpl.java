package com.example.homeloan.layer3;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.homeloan.layer2.DocTable;

@Repository
public class DocTableRepoImpl implements DocTableRepo {
	
	@PersistenceContext
	 EntityManager entityManager;
	
	@Transactional
	public void adddoc(DocTable dRef) {
		entityManager.persist(dRef);

	}

	public DocTable findDocTable(int dno) {
		System.out.println("Department repo....NO scope of bussiness logic here...");
		return entityManager.find(DocTable.class,dno);
		
	}
	@Transactional
	public List<DocTable> findDocTables() {
		List<DocTable> DocList;
		DocList = new ArrayList<DocTable>();
		
			String queryString = "from DocTable";
			Query query = entityManager.createQuery(queryString);
			DocList = query.getResultList();
			
		
		return DocList;
	}
	@Transactional

	public void modifyDocTable(DocTable dRef) {
		entityManager.merge(dRef);

	}
	
	@Transactional
	public void removeDocTable(int dno) {
		
		DocTable dTemp = entityManager.find(DocTable.class,dno);
		entityManager.remove(dTemp);
	}

	@Transactional
	public Set<DocTable> findDocByUserId(int dno) {
		Set<DocTable> docSet;
		
			Query query = entityManager.createQuery("from DocTable e where rep_id =:myno",DocTable.class).setParameter("myno", dno);
			//empSet = (Set<Employee2>) query.getResultList().stream().collect(Collectors.toSet());
			
			docSet = new HashSet(query.getResultList());
				
			
		return docSet;
	}

	

}