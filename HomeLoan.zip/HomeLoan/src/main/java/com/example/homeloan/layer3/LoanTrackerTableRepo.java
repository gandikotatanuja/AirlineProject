package com.example.homeloan.layer3;

import java.util.List;
import java.util.Set;

import com.example.homeloan.layer2.LoanTrackerTable;

public interface LoanTrackerTableRepo {

	void addLoanTracker(LoanTrackerTable lRef);		//	C - add - insert
	LoanTrackerTable findLoanTracker(int lno);			//  R - find - select
	List<LoanTrackerTable> findLoanTrackers();			//  R - find - select all
	void modifyLoanTracker(LoanTrackerTable lRef);		//  U - modify - update
	void removeLoanTracker(int lno);
	Set<LoanTrackerTable> findLoanAppIdByUserId(int i);
}