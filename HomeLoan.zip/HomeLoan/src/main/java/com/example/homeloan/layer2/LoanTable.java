package com.example.homeloan.layer2;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the LOAN_TABLE database table.
 * 
 */
@Entity
@Table(name="LOAN_TABLE")
@NamedQuery(name="LoanTable.findAll", query="SELECT l FROM LoanTable l")
public class LoanTable implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name="LOAN_ID")
	private int loanId;

	@Column(name="INTEREST_RATE")
	private float interestRate;

	@Column(name="LOAN_AMOUNT")
	private double loanAmount;

	@Column(name="MAX_LOAN")
	private double maxLoan;

	@Column(updatable=false)
	private int tenure;

	//bi-directional one-to-one association to ProTable
	@OneToOne(mappedBy="loanTable",cascade = CascadeType.ALL, fetch=FetchType.EAGER)
	private ProTable proTable;

	public LoanTable() {
		System.out.println("loantable const() called...");
	}

	public int getLoanId() {
		return loanId;
	}

	public void setLoanId(int loanId) {
		this.loanId = loanId;
	}

	public float getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(float interestRate) {
		this.interestRate = interestRate;
	}

	public double getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}

	public double getMaxLoan() {
		return maxLoan;
	}

	public void setMaxLoan(double maxLoan) {
		this.maxLoan = maxLoan;
	}

	public int getTenure() {
		return tenure;
	}

	public void setTenure(int tenure) {
		this.tenure = tenure;
	}

	public ProTable getProTable() {
		return proTable;
	}

	public void setProTable(ProTable proTable) {
		this.proTable = proTable;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	

}