package com.example.homeloan.layer3;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.homeloan.layer2.DocTable;
import com.example.homeloan.layer2.IncomeTable;


	@Repository
	public class IncomeTableRepoImpl implements IncomeTableRepo {

		@PersistenceContext
		 EntityManager entityManager;//auto injected by spring by reading 
											//persistance.xml file
		@Transactional
		public void addIncome(IncomeTable iref) {
			System.out.println("add Income started..");
			entityManager.persist(iref);

		}
		@Transactional
		public IncomeTable findIncome(int ino) {
			
			System.out.println("Income repo....NO scope of bussiness logic here...");
			return entityManager.find(IncomeTable.class,ino);
		}

		@Transactional
		public List<IncomeTable> findIncomes() {
			List<IncomeTable> deptList;
			deptList = new ArrayList<IncomeTable>();
			
				String queryString = "from IncomeTable";
				Query query = entityManager.createQuery(queryString);
				deptList = query.getResultList();
				
			return deptList;
		}
		@Transactional
		public void modifyIncome(IncomeTable iref) {
			
			entityManager.merge(iref);
		}
		@Transactional
		public void removeIncome(int ino) {
			IncomeTable iTemp = entityManager.find(IncomeTable.class,ino);
			entityManager.remove(iTemp);

		}
		@Override
		public Set<IncomeTable> findIncomeByUserId(int dno) {
			
			Set<IncomeTable> docSet;
				Query query = entityManager.createQuery("from IncomeTable e where user_id =:myno",IncomeTable.class).setParameter("myno", dno);
				docSet = new HashSet(query.getResultList());	
			return docSet;
		}
	}