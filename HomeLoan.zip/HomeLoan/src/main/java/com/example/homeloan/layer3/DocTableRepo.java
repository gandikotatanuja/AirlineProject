package com.example.homeloan.layer3;

import java.util.List;
import java.util.Set;

import com.example.homeloan.layer2.DocTable;

public interface DocTableRepo {
	 void adddoc(DocTable dRef);
		DocTable findDocTable(int dno);			
		List<DocTable> findDocTables();			
		void modifyDocTable(DocTable dRef);
		void removeDocTable(int dno);
		Set<DocTable> findDocByUserId(int dno);
		 
}
