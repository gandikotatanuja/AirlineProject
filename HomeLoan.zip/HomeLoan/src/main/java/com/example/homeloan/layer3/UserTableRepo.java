package com.example.homeloan.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.homeloan.layer2.UserTable;

@Repository
public interface UserTableRepo // POJO crud interface
	{
		void addUser(UserTable uRef);		//	C - add - insert
		UserTable findUser(int uno);			//  R - find - select
		List<UserTable> findUsers();			//  R - find - select all
		void modifyUser(UserTable uRef);		//  U - modify - update
		void removeUser(int uno);     //  D - remove - delete
		
	}

