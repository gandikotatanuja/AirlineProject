package com.example.homeloan.layer2;
import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the DOC_TABLE database table.
 * 
 */
@Entity
@Table(name="DOC_TABLE")
@NamedQuery(name="DocTable.findAll", query="SELECT d FROM DocTable d")
public class DocTable implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name="DOC_ID")
	private int docId;

	private String agreement;

	private String loa;

	private String noc;

	@Column(name="PAN_CARD")
	private String panCard;

	private String salaryslip;

	@Column(name="VOTER_ID")
	private String voterId;

	//bi-directional one-to-one association to LoantrackerTable
	@OneToOne
	@JoinColumn(name="DOC_ID", referencedColumnName="DOC_ID")
	private LoanTrackerTable loanTrackerTable;

	
	@ManyToOne
	@JoinColumn(name="REP_ID")
	private UserTable userTable;

	public DocTable() {
	}

	public int getDocId() {
		return docId;
	}

	public void setDocId(int docId) {
		this.docId = docId;
	}

	public String getAgreement() {
		return agreement;
	}

	public void setAgreement(String agreement) {
		this.agreement = agreement;
	}

	public String getLoa() {
		return loa;
	}

	public void setLoa(String loa) {
		this.loa = loa;
	}

	public String getNoc() {
		return noc;
	}

	public void setNoc(String noc) {
		this.noc = noc;
	}

	public String getPanCard() {
		return panCard;
	}

	public void setPanCard(String panCard) {
		this.panCard = panCard;
	}

	public String getSalaryslip() {
		return salaryslip;
	}

	public void setSalaryslip(String salaryslip) {
		this.salaryslip = salaryslip;
	}

	public String getVoterId() {
		return voterId;
	}

	public void setVoterId(String voterId) {
		this.voterId = voterId;
	}

	public LoanTrackerTable getLoanTrackerTable() {
		return loanTrackerTable;
	}

	public void setLoanTrackerTable(LoanTrackerTable loanTrackerTable) {
		this.loanTrackerTable = loanTrackerTable;
	}

	public UserTable getUserTable() {
		return userTable;
	}

	public void setUserTable(UserTable userTable) {
		this.userTable = userTable;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
}