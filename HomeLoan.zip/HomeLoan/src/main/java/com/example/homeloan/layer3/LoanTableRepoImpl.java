package com.example.homeloan.layer3;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.homeloan.layer2.LoanTable;



@Repository
public class LoanTableRepoImpl implements LoanTableRepo {
    
	@PersistenceContext
	 EntityManager entityManager;
	
	@Transactional
	public void addLoan(LoanTable lRef) {
		entityManager.persist(lRef);

	}
	@Transactional
	public LoanTable findLoan(int lno) {
		System.out.println("Loan  repo....NO scope of bussiness logic here...");
		return entityManager.find(LoanTable.class,lno);
		
	}
	@SuppressWarnings("unchecked")
	@Transactional
	public List<LoanTable> findLoans() {
		List<LoanTable> LoanList;
		LoanList = new ArrayList<LoanTable>();
		
			String queryString = "from LoanTable";
			Query query = entityManager.createQuery(queryString);
			LoanList = query.getResultList();	
		
		return LoanList;	
		
	}
	
	@Transactional
	public void modifyLoan(LoanTable lRef) {
		entityManager.merge(lRef);
	}
	@Transactional
	public void removeLoan(int lno) {
		LoanTable lTemp = entityManager.find(LoanTable.class,lno);
		entityManager.remove(lTemp);
	}
	
}