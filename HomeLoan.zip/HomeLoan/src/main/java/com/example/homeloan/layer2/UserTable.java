package com.example.homeloan.layer2;
import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the USER_TABLE database table.
 * 
 */
@Entity
@Table(name="USER_TABLE")
@NamedQuery(name="UserTable.findAll", query="SELECT u FROM UserTable u")
public class UserTable implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name="USER_ID")
	private int userId;

	private String address;

	@Column(name="ADHAR_NO")
	private long adharNo;

	@Column(name="CONFIRM_PASSWORD")
	private String confirmPassword;

	@Temporal(TemporalType.DATE)
	private Date dob;

	private String fname;

	private String gender;

	private String lname;

	private String mailid;

	private String mname;

	private String nationality;

	@Column(name="PAN_NO")
	private String panNo;

	private String password;

	private Long phoneno;

	//bi-directional many-to-one association to IncomeTable
	@OneToMany(mappedBy="userTable", fetch=FetchType.EAGER,cascade = CascadeType.ALL)
	private Set<IncomeTable> incomeTables;

	//bi-directional many-to-one association to DocTable
	@OneToMany(mappedBy="userTable", fetch=FetchType.EAGER,cascade = CascadeType.ALL)
	private Set<DocTable> docTables;

	public UserTable() {
		System.out.println("usertable const() called...");
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public long getAdharNo() {
		return adharNo;
	}

	public void setAdharNo(long adharNo) {
		this.adharNo = adharNo;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getMailid() {
		return mailid;
	}

	public void setMailid(String mailid) {
		this.mailid = mailid;
	}

	public String getMname() {
		return mname;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getPanNo() {
		return panNo;
	}

	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Long getPhoneno() {
		return phoneno;
	}

	public void setPhoneno(Long phoneno) {
		this.phoneno = phoneno;
	}

	public Set<IncomeTable> getIncomeTables() {
		return incomeTables;
	}

	public void setIncomeTables(Set<IncomeTable> incomeTables) {
		this.incomeTables = incomeTables;
	}

	public Set<DocTable> getDocTables() {
		return docTables;
	}

	public void setDocTables(Set<DocTable> docTables) {
		this.docTables = docTables;
	}
	public IncomeTable addIncomeTable(IncomeTable incomeTable) {
		getIncomeTables().add(incomeTable);
		incomeTable.setUserTable(this);

		return incomeTable;
	}

	public IncomeTable removeIncomeTable(IncomeTable incomeTable) {
		getIncomeTables().remove(incomeTable);
		incomeTable.setUserTable(null);

		return incomeTable;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
	

}