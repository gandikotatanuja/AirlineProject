package com.example.homeloan.layer4;

import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.homeloan.layer2.Income;
import com.example.homeloan.layer3.IncomeRepo;
import com.example.homeloan.layer4.exceptions.IncomeAlreadyExistException;
import com.example.homeloan.layer4.exceptions.IncomeNotFoundException;

@Service
public class IncomeServiceImpl implements IncomeService {
		
	@Autowired
	IncomeRepo incomeRepo;
	
	@Override
	public Income findIncomeService(int dno) throws IncomeNotFoundException {
		System.out.println("Income Service....Some scope of bussiness logic here...");
		return incomeRepo.findIncome(dno);
	}
	
	@Override
	public String removeIncomeService(int dno) throws IncomeNotFoundException {
		Income d =incomeRepo.findIncome(dno);
		if(d!=null)
		{incomeRepo.removeIncome(d.getIncomeId());}
		else {
			throw new IncomeNotFoundException("IncomeRow Not Found");
		}
		return "IncomeRow Deleted successfully";
	}

	@Override
	public String addIncomeService(Income dRef) throws IncomeAlreadyExistException {
		System.out.println("Income Service....Some scope of bussiness logic here...");
		try {
			incomeRepo.addIncome(dRef);
		}
		catch (Exception e) {
			throw new IncomeAlreadyExistException("Income already exists");	
		}
		return "IncomeRow added successfully";
	}

	@Override
	public String modifyIncomeService(Income dRef) throws IncomeNotFoundException {
		System.out.println("Income Service....Some scope of bussiness logic here...");
		
		Income d =incomeRepo.findIncome(dRef.getIncomeId());
		if(d!=null)
		{incomeRepo.modifyIncome(dRef);}
		else {
			throw new IncomeNotFoundException("IncomeRow Not Found");
		}
		return "IncomeRow modified successfully";
	}

	@Override
	public Set<Income> findIncomesService() {
		System.out.println("Income Service....Some scope of bussiness logic here...");
		return incomeRepo.findIncomes();
	}

}
