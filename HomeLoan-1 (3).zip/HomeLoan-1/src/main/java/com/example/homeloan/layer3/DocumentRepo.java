package com.example.homeloan.layer3;


import java.util.Set;

import org.springframework.stereotype.Repository;

import com.example.homeloan.layer2.Document;

@Repository
public interface DocumentRepo {
		void addDocument(Document dRef);
		Document findDocument(int dno);			
		Set<Document> findDocuments();			
		void modifyDocument(Document dRef);
		void removeDocument(int dno);
		Set<Document> findDocumentByUserId(int dno);
		 
}
