package com.example.homeloan.layer3;

import java.util.Set;

import org.springframework.stereotype.Repository;

import com.example.homeloan.layer2.Loan;

@Repository
public interface LoanRepo{

	void addLoan(Loan lRef);		//	C - add - insert
	Loan findLoan(int lno);			//  R - find - select
	Set<Loan> findLoans();			//  R - find - select all
	void modifyLoan(Loan lRef);		//  U - modify - update
	void removeLoan(int lno);		// D-delete
	Set<Loan> findLoanByUserId(int dno); //Business
}