package com.example.homeloan.layer4;

import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.homeloan.layer2.UserRegistration;
import com.example.homeloan.layer3.UserRegistrationRepo;
import com.example.homeloan.layer4.exceptions.UserAlreadyExistException;
import com.example.homeloan.layer4.exceptions.UserNotFoundException;

@Service
public class UserRegistrationServiceImpl implements UserRegistrationService {

	@Autowired
	UserRegistrationRepo userRepo;
	
	@Override
		public String addUserService(UserRegistration uRef) throws UserAlreadyExistException {
			System.out.println("User Service....Some scope of bussiness logic here...");
			try {
				userRepo.addUser(uRef);
				
			} catch (Exception e) {
				
				throw new UserAlreadyExistException("User Already Exist");
			}
			return "User added successfully";

			}
	
	@Override
	public UserRegistration findUserService(int uno)throws UserNotFoundException  {
		System.out.println("User Service....Some scope of bussiness logic here...");
		UserRegistration user = userRepo.findUser(uno);
		if(user == null) {
			throw new UserNotFoundException("User Not Found");
		}
		return user;
	}
	@Override
	public String modifyUserService(UserRegistration uRef) throws UserNotFoundException {
		UserRegistration user = userRepo.findUser(uRef.getUserId());
		if(user == null) {
			throw new UserNotFoundException("User Not Found");	
		}
		else {
			userRepo.modifyUser(uRef);
		}
		return "User modifed successfully";
	}
	@Override
	public String removeUserService(int uno) throws UserNotFoundException  {	
		UserRegistration user = userRepo.findUser(uno);
		if(user == null) {
		throw new UserNotFoundException("User Not Found");
		}
		else {
		userRepo.removeUser(uno);
		}		
		return "User Deleted successfully";
		}

	@Override
	public Set<UserRegistration> findUsersService() {
		System.out.println("User Service....Some scope of bussiness logic here...");
		return userRepo.findUsers();
	}

}
