package com.example.homeloan.layer4.exceptions;

@SuppressWarnings("serial")
public class DocumentAlreadyExistException extends Exception{
	public DocumentAlreadyExistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
