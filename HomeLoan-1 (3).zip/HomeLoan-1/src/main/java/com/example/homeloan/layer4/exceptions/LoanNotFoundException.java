package com.example.homeloan.layer4.exceptions;


@SuppressWarnings("serial")
public class LoanNotFoundException extends Exception {

	public LoanNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
