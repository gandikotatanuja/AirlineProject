package com.example.homeloan.layer2;
import java.io.Serializable;
import java.util.Set;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the DOC_TABLE database table.
 * 
 */
@Entity
@Table(name="DOC_TABLE")
@NamedQuery(name="Document.findAll", query="SELECT d FROM Document d")
public class Document implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name="DOC_ID")
	private int docId;

	private String agreement;

	private String loa;

	private String noc;

	@Column(name="PAN_CARD")
	private String panCard;

	private String salaryslip;

	@Column(name="VOTER_ID")
	private String voterId;

	//bi-directional one-to-one association to LoantrackerTable
	@OneToMany(mappedBy="document", fetch=FetchType.EAGER)
	private Set<LoanTracker> loanTracker;
	
	@ManyToOne
	@JoinColumn(name="REP_ID")
	private UserRegistration userRegistration;

	public Document() {
	}

	public int getDocId() {
		return docId;
	}

	public void setDocId(int docId) {
		this.docId = docId;
	}

	public String getAgreement() {
		return agreement;
	}

	public void setAgreement(String agreement) {
		this.agreement = agreement;
	}

	public String getLoa() {
		return loa;
	}

	public void setLoa(String loa) {
		this.loa = loa;
	}

	public String getNoc() {
		return noc;
	}

	public void setNoc(String noc) {
		this.noc = noc;
	}

	public String getPanCard() {
		return panCard;
	}

	public void setPanCard(String panCard) {
		this.panCard = panCard;
	}

	public String getSalaryslip() {
		return salaryslip;
	}

	public void setSalaryslip(String salaryslip) {
		this.salaryslip = salaryslip;
	}

	public String getVoterId() {
		return voterId;
	}

	public void setVoterId(String voterId) {
		this.voterId = voterId;
	}
	@JsonIgnore
	public Set<LoanTracker> getLoanTracker() {
		return loanTracker;
	}

	public void setLoanTracker(Set<LoanTracker> loanTracker) {
		this.loanTracker = loanTracker;
	}

	
	//@JsonIgnore
	public UserRegistration getUserRegistration() {
		return userRegistration;
	}

	public void setUserRegistration(UserRegistration userRegistration) {
		this.userRegistration = userRegistration;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}