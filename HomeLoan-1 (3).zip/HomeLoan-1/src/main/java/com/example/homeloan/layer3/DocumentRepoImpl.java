package com.example.homeloan.layer3;


import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.homeloan.layer2.Document;

@Repository
public class DocumentRepoImpl implements DocumentRepo {
	
	@PersistenceContext
	 EntityManager entityManager;
	
	@Transactional
	public void addDocument(Document dRef) {
		entityManager.persist(dRef);

	}
	@Transactional
	public Document findDocument(int dno) {
		System.out.println("Department repo....NO scope of bussiness logic here...");
		return entityManager.find(Document.class,dno);
		
	}
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Transactional
	public Set<Document> findDocuments()
	{
			Set<Document> docSet;
			docSet = new HashSet<Document>();
			String queryString = "from Document";
			Query query = entityManager.createQuery(queryString);
			docSet = new HashSet(query.getResultList());
			return docSet;
	}
	
	@Transactional
	public void modifyDocument(Document dRef) 
	{
		entityManager.merge(dRef);

	}
	
	@Transactional
	public void removeDocument(int dno) 
	{
		
		Document dTemp = entityManager.find(Document.class,dno);
		entityManager.remove(dTemp);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Transactional
	public Set<Document> findDocumentByUserId(int dno) 
	{
			Set<Document> docSet;
			Query query = entityManager.createQuery("from Document e where rep_id =:myno",Document.class).setParameter("myno", dno);
			docSet = new HashSet(query.getResultList());	
			return docSet;
	}

	
	

}