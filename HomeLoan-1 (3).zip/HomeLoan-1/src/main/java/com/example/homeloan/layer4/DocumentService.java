package com.example.homeloan.layer4;

import java.util.Set;

import org.springframework.stereotype.Service;

import com.example.homeloan.layer4.exceptions.DocumentAlreadyExistException;
import com.example.homeloan.layer4.exceptions.DocumentNotFoundException;
import com.example.homeloan.layer2.Document;

@Service
public interface DocumentService {
	
		    String addDocumentService(Document dRef) throws DocumentAlreadyExistException;
			Document findDocumentService(int dno) throws DocumentNotFoundException; 			
			Set<Document> findDocumentServices();			
			String modifyDocumentService(Document dRef) throws DocumentNotFoundException; 
			String removeDocumentService(int dno) throws DocumentNotFoundException;
		//	Set<Document> findDocByUserIdService(int dno);
}
