package com.example.homeloan.layer4.exceptions;

@SuppressWarnings("serial")
public class IncomeNotFoundException extends Exception{

	public IncomeNotFoundException(String message)
	{
		super(message);
	}
}
