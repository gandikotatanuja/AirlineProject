package com.example.homeloan.layer4;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.homeloan.layer2.Property;
import com.example.homeloan.layer3.PropertyRepo;
import com.example.homeloan.layer4.exceptions.PropertyAlreadyExsitException;
import com.example.homeloan.layer4.exceptions.PropertyNotFoundException;

@Service
public class PropertyServiceImpl implements PropertyService 
{
		@Autowired	
		PropertyRepo propertyRepo;
		
		@Override
		public String addPropertyService(Property pRef) throws PropertyAlreadyExsitException  {
			System.out.println("property Service....Some scope of bussiness logic here...");
			try {
				propertyRepo.addProperty(pRef);
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				throw new PropertyAlreadyExsitException("property Already Exsist");
			}
			return "ProTable added successfully";
		}
		
		@Override
		public Property findPropertyService(int pno) throws PropertyNotFoundException {
			System.out.println("property Service....NO scope of bussiness logic here...");
			Property property = propertyRepo.findProperty(pno);
			if(property == null) {
				throw new PropertyNotFoundException("property Not Found");
			}
			return property;
		}
			
		
	
		@Override
		public  String modifyPropertyService(Property pRef) throws PropertyNotFoundException{
			Property property =propertyRepo.findProperty(pRef.getProId());
			if( property== null) {
				throw new PropertyNotFoundException("property Not Found");
				
			}
			else {
				propertyRepo.modifyProperty(pRef);
			}
				
				return "ProTable modifed successfully";
	      }

	
		@Override
		public String removePropertyService(int pno) throws PropertyNotFoundException {
			Property property = propertyRepo.findProperty(pno);
			if(property== null) {
				throw new PropertyNotFoundException("property Not Found");
				
			}
			else {
				propertyRepo.removeProperty(pno);
			}
				
		return "property Deleted successfully";
	
		}
		@Override
		public Set<Property> findPropertiesService() {
			System.out.println("property Service....Some scope of bussiness logic here...");
			return propertyRepo.findPropertys();
		}
		
		
		}
