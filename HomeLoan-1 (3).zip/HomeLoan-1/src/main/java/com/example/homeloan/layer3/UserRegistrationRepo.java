package com.example.homeloan.layer3;
import java.util.Set;
import org.springframework.stereotype.Repository;
import com.example.homeloan.layer2.UserRegistration;

@Repository
public interface UserRegistrationRepo
{
		void addUser(UserRegistration uRef);		//	C - add - insert
		UserRegistration findUser(int uno);			//  R - find - select
		Set<UserRegistration> findUsers();			//  R - find - select all
		void modifyUser(UserRegistration uRef);		//  U - modify - update
		void removeUser(int uno);     //  D - remove - delete
		
}

