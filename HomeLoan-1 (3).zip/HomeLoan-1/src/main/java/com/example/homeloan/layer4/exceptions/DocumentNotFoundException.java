package com.example.homeloan.layer4.exceptions;


@SuppressWarnings("serial")
public class DocumentNotFoundException extends Exception {

	public DocumentNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
