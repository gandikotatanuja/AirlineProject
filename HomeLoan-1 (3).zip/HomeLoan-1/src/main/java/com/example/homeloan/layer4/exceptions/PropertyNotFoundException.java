package com.example.homeloan.layer4.exceptions;

@SuppressWarnings("serial")
public class PropertyNotFoundException extends Exception {

	public PropertyNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}