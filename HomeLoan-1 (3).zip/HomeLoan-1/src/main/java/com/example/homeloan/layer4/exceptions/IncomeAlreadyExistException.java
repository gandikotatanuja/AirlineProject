package com.example.homeloan.layer4.exceptions;

@SuppressWarnings("serial")
public class IncomeAlreadyExistException extends Exception{

	public IncomeAlreadyExistException(String message)
	{
		super(message);
	}
}
