
package com.example.homeloan.layer3;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.example.homeloan.layer2.Income;
import com.example.homeloan.layer2.LoanTracker;

@Repository
public class LoanTrackerRepoImpl implements LoanTrackerRepo
{

		@PersistenceContext
		 EntityManager entityManager;
		
		@Transactional
		public void addLoanTracker(LoanTracker lRef)
		{
			entityManager.persist(lRef);

		}

		@Transactional
		public LoanTracker findLoanTracker(int lno)
		{
			System.out.println("LoanTracker repo....NO scope of bussiness logic here...");
			return entityManager.find(LoanTracker.class,lno);
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		@Transactional
		public Set<LoanTracker> findLoanTrackers() {
			Set<LoanTracker> loanSet;
			loanSet = new HashSet<LoanTracker>();
			Query query = entityManager.createNativeQuery("select * from LOANTRACKER_TABLE",LoanTracker.class);
			loanSet = new HashSet(query.getResultList());
			return loanSet;
		}

		@Transactional
		public void modifyLoanTracker(LoanTracker lRef) {
	     	entityManager.merge(lRef);

		}

		@Transactional
		public void removeLoanTracker(int lno) {
			LoanTracker lTemp = entityManager.find(LoanTracker.class,lno);
			entityManager.remove(lTemp);
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		@Transactional
		public Set<LoanTracker> findLoanAppIdByUserId(int i)
		{
			Set<LoanTracker> docSet;
			Query query = entityManager.createNativeQuery("select * from loantracker_table where doc_id=(select doc_id from doc_table where rep_id=101)",LoanTracker.class);
			docSet = new HashSet(query.getResultList());
			return docSet;
		}

	}

