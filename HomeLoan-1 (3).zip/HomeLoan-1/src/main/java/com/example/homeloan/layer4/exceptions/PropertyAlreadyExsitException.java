package com.example.homeloan.layer4.exceptions;


@SuppressWarnings("serial")
public class PropertyAlreadyExsitException extends Exception {

	public PropertyAlreadyExsitException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}