package com.example.homeloan.layer4;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.homeloan.layer2.Document;
import com.example.homeloan.layer2.UserRegistration;
import com.example.homeloan.layer3.DocumentRepo;
import com.example.homeloan.layer4.exceptions.DocumentAlreadyExistException;
import com.example.homeloan.layer4.exceptions.DocumentNotFoundException;
@Service
public class DocumentServiceImpl implements DocumentService {
	
	@Autowired
	DocumentRepo documentRepo;
		
	@Override
	public String addDocumentService(Document dRef) throws DocumentAlreadyExistException
	{
		System.out.println("Document Service....Some scope of bussiness logic here...");
		try {
			documentRepo.addDocument(dRef);	
			} 
		catch (Exception e) {		
				throw new DocumentAlreadyExistException("Document Already Exist");
			}
			return "Document added successfully";
	}
	
	@Override
	public Document findDocumentService(int dno) throws  DocumentNotFoundException
	{
			System.out.println("Document Service....Some scope of bussiness logic here...");
			Document doc = documentRepo.findDocument(dno);
			if(doc == null) {
				throw new DocumentNotFoundException("Document Not Found");
			}
			return doc;
			
	}
		
	@Override
	public Set<Document> findDocumentServices() 
	{	
		System.out.println("Document Service....Some scope of bussiness logic here...");
		return documentRepo.findDocuments();
	}
		
	@Override
	public String modifyDocumentService(Document dRef) throws  DocumentNotFoundException 
	{	
		Document doc = documentRepo.findDocument(dRef.getDocId());
		if(doc == null) {
				throw new DocumentNotFoundException("Document Not Found");
				
	}
		else 
		{              
			//UserRegistration user=userRepo.findUser(101);
			//doc.setUserRegistration(user);
			UserRegistration user=doc.getUserRegistration();
			dRef.getUserRegistration().setUserId(user.getUserId());
			documentRepo.modifyDocument(dRef);
			user.getUserId();
		}
				
		return "Document modifed successfully";
	}
	@Override
	public String removeDocumentService(int dno) throws  DocumentNotFoundException
	{	
			Document doc = documentRepo.findDocument(dno);
			if(doc == null)
			{
				throw new DocumentNotFoundException("Document Not Found");	
			}
			else {
				documentRepo.removeDocument(dno);
			}
				
			 return "Document Deleted successfully";
	}

/*	@Override
	public Set<Document> findDocByUserIdService(int dno) {
		
		Set<Document> doc = documentRepo.findDocumentByUserId(dno);
		if(doc == null)
		{
			throw new UserNotFoundException("User Not Found");	
		}
		else {
			documentRepo.findDocumentByUserId(dno);
		}
		//Set<Employee2> empSet =dept.getEmpSet();
		Set<Document> docSet=  doc.getdocSet();
		return null;
		Set<Document> docSet;
		Query query = entityManager.createQuery("from Document e where rep_id =:myno",Document.class).setParameter("myno", dno);
		docSet = new HashSet(query.getResultList());	
		return docSet;
	}*/

}
