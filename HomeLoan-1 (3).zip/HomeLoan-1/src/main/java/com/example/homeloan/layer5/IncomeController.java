package com.example.homeloan.layer5;

import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.homeloan.layer2.Income;
import com.example.homeloan.layer2.UserRegistration;
import com.example.homeloan.layer3.UserRegistrationRepo;
import com.example.homeloan.layer4.IncomeService;
import com.example.homeloan.layer4.exceptions.IncomeAlreadyExistException;
import com.example.homeloan.layer4.exceptions.IncomeNotFoundException;

@CrossOrigin(origins="http://localhost:4200")//connecting spring with Angular
@RestController  //REpresentational State Transfer html xml json
public class IncomeController {
	
	@Autowired
	IncomeService incomeServ;
	@Autowired
	UserRegistrationRepo userRepo;
	
	@GetMapping(path="/getIncome/{myincome}")
	@ResponseBody
	public ResponseEntity<Income> getDepartment(@PathVariable("myincome") Integer dno) throws IncomeNotFoundException {
		System.out.println("Income Controller....Understanding client and talking to service layer...");
		Income income=null;
		
		income = incomeServ.findIncomeService(dno);
			if(income==null)
			{ 
				return ResponseEntity.notFound().build();
			}
			else {
				return ResponseEntity.ok(income);
			}
		
	}

	@GetMapping(path="/getincomes")
	@ResponseBody
	public Set<Income> getAllDepartments() {
		System.out.println("Income Controller....Understanding client and talking to service layer...");
		Set<Income> incomeSet = incomeServ.findIncomesService();
		return incomeSet;
		
	}
	
	@PostMapping(path="/addIncome")
	public String addIncome(@RequestBody Income inc) {
		System.out.println("Income Controller....Understanding client and talking to service layer...");
		
		Income income =new Income();
		income.setIncomeId(inc.getIncomeId());
		income.setTypeOfEmp(inc.getTypeOfEmp());
		income.setRetirementAge(inc.getRetirementAge());
		income.setOrganizationType(inc.getOrganizationType());
		income.setEmployerName(inc.getEmployerName());
		UserRegistration user=userRepo.findUser(103);
		income.setUserRegistration(user);
		System.out.println(user);
	
		String stmsg = null;
		try {
			stmsg =incomeServ.addIncomeService(inc);
		} 
		catch (IncomeAlreadyExistException e) 
		{
			e.printStackTrace();
			return e.getMessage();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		  return stmsg;
		
	}
	
	@PutMapping(path="/modifyIncome")
	public String modifyDepartment(@RequestBody Income inc)throws IncomeNotFoundException
	{
		System.out.println("Income Controller....Understanding client and talking to service layer...");
		
		String stmsg = null;
		try {
			
			stmsg = incomeServ.modifyIncomeService(inc);
		} 
		catch (IncomeNotFoundException e)
		{
			e.printStackTrace();
			return e.getMessage();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		  return stmsg;
		
	}
	
	@DeleteMapping(path="/deleteIncome")
	public String removeDepartment(@RequestBody Income inc)throws IncomeNotFoundException {
		System.out.println("Income Controller....Understanding client and talking to service layer...");
		 String stmsg = null;
		try {
			stmsg = incomeServ.removeIncomeService(inc.getIncomeId());
		} 
		catch (IncomeNotFoundException e)
		{
			e.printStackTrace();
			return e.getMessage();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		  return stmsg;
		
	}
	
}
