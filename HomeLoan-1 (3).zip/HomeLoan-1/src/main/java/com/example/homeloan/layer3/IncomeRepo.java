package com.example.homeloan.layer3;

import java.util.Set;

import org.springframework.stereotype.Repository;

import com.example.homeloan.layer2.*;

@Repository
public interface IncomeRepo {


	void addIncome(Income iref);		//	C - add - insert
	Income findIncome(int ino);			//  R - find - select
	Set<Income> findIncomes();			//  R - find - select all
	void modifyIncome(Income iref);		//  U - modify - update
	void removeIncome(int ino);		//  D
	Set<Income> findIncomeByUserId(int ino);
}
