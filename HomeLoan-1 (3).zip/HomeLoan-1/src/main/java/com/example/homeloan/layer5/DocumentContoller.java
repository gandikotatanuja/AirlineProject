package com.example.homeloan.layer5;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.homeloan.layer2.Document;
import com.example.homeloan.layer2.LoanTracker;
import com.example.homeloan.layer2.UserRegistration;
import com.example.homeloan.layer3.UserRegistrationRepo;
import com.example.homeloan.layer4.DocumentService;
import com.example.homeloan.layer4.exceptions.DocumentAlreadyExistException;
import com.example.homeloan.layer4.exceptions.DocumentNotFoundException;

@RestController
public class DocumentContoller {
	
	@Autowired
	DocumentService docServ;
	
	@Autowired
	UserRegistrationRepo userRepo;
	 	
	
	@GetMapping(path="/getDoc/{mydno}")
	@ResponseBody
	public ResponseEntity<Document> getDocument(@PathVariable("mydno") Integer dno) throws DocumentNotFoundException {
			System.out.println("Document  Controller....Understanding client and talking to service layer...");
			Document doc=null;
			
				doc = docServ.findDocumentService(dno);
				if(doc==null)
				{ 
					return ResponseEntity.notFound().build();
				
				}
				else {
					return ResponseEntity.ok(doc);
				}
			
		}
		
		
		@GetMapping(path="/getDocs")
		@ResponseBody
		public Set<Document> getAllDocuments() {
			System.out.println("Department Controller....Understanding client and talking to service layer...");
			Set<Document> docSet = docServ.findDocumentServices();
			return docSet;
			
		}
		
		@GetMapping(path="/getLoantrackersOfDoc")
		@ResponseBody
		public Set<LoanTracker> getAllloantrackersbydocid() {
			System.out.println("Document Controller....Understanding client and talking to service layer...");
			Document doc=null;
			try {
				doc = docServ.findDocumentService(701);
			} catch (DocumentNotFoundException e) {
				e.printStackTrace();
			}
			Set<LoanTracker> loanSet =doc.getLoanTracker();
			return loanSet;			
		}
		
		@PostMapping(path="/addDoc")
		public String addDocument(@RequestBody Document doc) {
			System.out.println("Department Controller....Understanding client and talking to service layer...");
			Document document=new Document();
			document.setDocId(doc.getDocId());
			document.setAgreement(doc.getAgreement());
			document.setLoa(doc.getLoa());
			document.setNoc(doc.getNoc());
			document.setPanCard(doc.getPanCard());
			document.setSalaryslip(doc.getSalaryslip());
			document.setVoterId(doc.getVoterId());
			UserRegistration user=userRepo.findUser(101);
			document.setUserRegistration(user);
			
			//document.setLoanTracker(doc.getLoanTracker());
			
			 String stmsg = null;
			try {
				stmsg = docServ.addDocumentService(document);
			} 
		 catch (DocumentAlreadyExistException e) {
				e.printStackTrace();
				return e.getMessage();
			}
			catch(Exception e) {
				e.printStackTrace();
				return e.getMessage();
			}
			System.out.println("controller printing"+stmsg);
			  return stmsg;
			
		}
		
		@PutMapping(path="/modifyDoc")
		public String modifyDocument(@RequestBody Document doc)throws DocumentNotFoundException {
			System.out.println("Department Controller....Understanding client and talking to service layer...");
			 String stmsg = null;
			try {
				stmsg = docServ.modifyDocumentService(doc);
				
				
			} 
			catch (DocumentNotFoundException e) {
				
				e.printStackTrace();
				return e.getMessage();
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			System.out.println("controller is saying: "+stmsg);
			  return stmsg;
			
		}
		
		@DeleteMapping(path="/deleteDoc")
		public String removeDocument(@RequestBody Document doc)throws DocumentNotFoundException {
			System.out.println("Department Controller....Understanding client and talking to service layer...");
			 String stmsg = null;
			try {
				stmsg = docServ.removeDocumentService(doc.getDocId());
			} 
			catch (DocumentNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return e.getMessage();
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			System.out.println("controller is saying: "+stmsg);
			  return stmsg;
			
		}
		
		@DeleteMapping(path="/deleteDocById/{mydno}")
		@ResponseBody
		public String removeDocumentbyId(@PathVariable("mydno")Integer dno)throws DocumentNotFoundException {
			System.out.println("Department Controller....Understanding client and talking to service layer...");
			 String stmsg = null;
			try {
				stmsg = docServ.removeDocumentService(dno);
			} 
			catch (DocumentNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return e.getMessage();
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			System.out.println("controller is saying: "+stmsg);
			  return stmsg;
			
		}
	}


