package com.example.homeloan.layer4;

import java.util.Set;

import org.springframework.stereotype.Service;

import com.example.homeloan.layer2.LoanTracker;
import com.example.homeloan.layer4.exceptions.LoanTrackerAlreadyExsitException;
import com.example.homeloan.layer4.exceptions.LoanTrackerNotFoundException;

@Service
public interface LoanTrackerService {
		String addLoanTrackerService(LoanTracker lRef)throws LoanTrackerAlreadyExsitException;  //C - add/create;
		LoanTracker findLoanTrackerService(int lno)throws LoanTrackerNotFoundException ;			//  R - find - select
		Set<LoanTracker> findLoanTrackersService();			//  R - find - select all
		String modifyLoanTrackerService(LoanTracker lRef) throws LoanTrackerNotFoundException;		//  U - modify - update
		String removeLoanTrackerService(int lno) throws LoanTrackerNotFoundException;
		//Set<LoanTrackerTable> findLoanAppIdByUserIdService(int i);
	}


