package com.example.homeloan.layer4;

import java.util.Set;


import org.springframework.stereotype.Service;
import com.example.homeloan.layer2.UserRegistration;
import com.example.homeloan.layer4.exceptions.UserNotFoundException;
import com.example.homeloan.layer4.exceptions.UserAlreadyExistException;

@Service
public interface UserRegistrationService // POJO crud interface
	{
		String addUserService(UserRegistration uRef) throws UserAlreadyExistException;		//	C - add - insert
		UserRegistration findUserService(int uno) throws UserNotFoundException;			//  R - find - select
		Set<UserRegistration> findUsersService();			//  R - find - select all
		String modifyUserService(UserRegistration uRef)throws UserNotFoundException;		//  U - modify - update
		String removeUserService(int uno)  throws UserNotFoundException  ; //  D - remove - delete
		

}