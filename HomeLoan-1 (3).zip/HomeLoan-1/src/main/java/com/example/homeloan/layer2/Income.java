package com.example.homeloan.layer2;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the INCOME_TABLE database table.
 * 
 */
@Entity
@Table(name="INCOME_TABLE")
@NamedQuery(name="Income.findAll", query="SELECT i FROM Income i")
public class Income implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name="INCOME_ID")
	private int incomeId;

	@Column(name="EMPLOYER_NAME")
	private String employerName;

	@Column(name="ORGANIZATION_TYPE")
	private String organizationType;

	@Column(name="RETIREMENT_AGE")
	private int retirementAge;

	@Column(name="TYPE_OF_EMP")
	private String typeOfEmp;

	//bi-directional many-to-one association to UserTable
	@ManyToOne
	@JoinColumn(name="USER_ID")
	private UserRegistration userRegistration;

	//bi-directional many-to-one association to ProTable
	@OneToMany(mappedBy="income", fetch=FetchType.EAGER,cascade = CascadeType.ALL)
	private Set<Property> property;

	public Income() {
	}

	public int getIncomeId() {
		return incomeId;
	}

	public void setIncomeId(int incomeId) {
		this.incomeId = incomeId;
	}

	public String getEmployerName() {
		return employerName;
	}

	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}

	public String getOrganizationType() {
		return organizationType;
	}

	public void setOrganizationType(String organizationType) {
		this.organizationType = organizationType;
	}

	public int getRetirementAge() {
		return retirementAge;
	}

	public void setRetirementAge(int retirementAge) {
		this.retirementAge = retirementAge;
	}

	public String getTypeOfEmp() {
		return typeOfEmp;
	}

	public void setTypeOfEmp(String typeOfEmp) {
		this.typeOfEmp = typeOfEmp;
	}

	public UserRegistration getUserRegistration() {
		return userRegistration;
	}

	public void setUserRegistration(UserRegistration userRegistration) {
		this.userRegistration = userRegistration;
	}

	public Set<Property> getProperty() {
		return property;
	}

	public void setProperty(Set<Property> property) {
		this.property = property;
	}

	public Property addProperty(Property property) {
		getProperty().add(property);
		property.setIncome(this);

		return property;
	}

	public Property removeProperty(Property property) {
		getProperty().remove(property);
		property.setIncome(null);

		return property;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
}