package com.example.homeloan.layer4;

import java.util.Set;
import org.springframework.stereotype.Service;
import com.example.homeloan.layer4.exceptions.LoanAlreadyExistException;
import com.example.homeloan.layer4.exceptions.LoanNotFoundException;
import com.example.homeloan.layer2.Loan;


@Service
public interface LoanService {

	String addLoanService(Loan lRef) throws LoanAlreadyExistException;		
	Loan findLoanService(int lno) throws LoanNotFoundException;			
	Set<Loan> findLoansService();			
	String modifyLoanService(Loan lRef) throws LoanNotFoundException;		
	String removeLoanService(int lno) throws LoanNotFoundException;     
}
