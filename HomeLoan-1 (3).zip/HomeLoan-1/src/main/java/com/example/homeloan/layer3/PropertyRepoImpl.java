package com.example.homeloan.layer3;


import java.util.HashSet;

import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.homeloan.layer2.Property;

@Repository
public class PropertyRepoImpl implements PropertyRepo {

	@PersistenceContext
	 EntityManager entityManager;
	
	@Transactional
	public void addProperty(Property pRef) {
		entityManager.persist(pRef);

	}
	@Transactional
	public Property findProperty(int pno) {
		System.out.println("property repo....NO scope of bussiness logic here...");
		return entityManager.find(Property.class,pno);
		
	}
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Transactional
	public Set<Property> findPropertys() {
		Set<Property> proSet;
		proSet = new HashSet<Property>();
		String queryString = "from Property";
		Query query = entityManager.createQuery(queryString);
		proSet = new HashSet(query.getResultList());
		return proSet;
	}
	@Transactional
	public void modifyProperty(Property pRef) {
		entityManager.merge(pRef);

	}
	@Transactional
	public void removeProperty(int pno) {
		Property pTemp = entityManager.find(Property.class,pno);
		entityManager.remove(pTemp);
			
		
	}
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Transactional
	public Set<Property> findPropertyByUserId(int i) 
	{
			Set<Property> docSet;		
			Query query = entityManager.createNativeQuery("select * from pro_table where income_id=(select income_id from income_table where user_id=101)",Property.class);
			docSet = new HashSet(query.getResultList());
			return docSet;
	}
}
