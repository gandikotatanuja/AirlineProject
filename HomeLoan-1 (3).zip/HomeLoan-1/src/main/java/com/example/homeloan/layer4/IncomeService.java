package com.example.homeloan.layer4;

import java.util.Set;
import org.springframework.stereotype.Service;
import com.example.homeloan.layer2.Income;
import com.example.homeloan.layer4.exceptions.IncomeAlreadyExistException;
import com.example.homeloan.layer4.exceptions.IncomeNotFoundException;

@Service
public interface IncomeService {
	String addIncomeService(Income dRef) throws IncomeAlreadyExistException;   //C - add/create
	 Income findIncomeService(int dno)throws IncomeNotFoundException;     //R - find/reading
	Set<Income> findIncomesService();     //R - find all/reading all
	String modifyIncomeService(Income dRef)throws IncomeNotFoundException; //U - modify/update
	String removeIncomeService(int dno)throws IncomeNotFoundException; //D - remove/delete
		
}
