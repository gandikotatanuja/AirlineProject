package com.example.homeloan.layer2;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the LOAN_TABLE database table.
 * 
 */
@Entity
@Table(name="LOAN_TABLE")
@NamedQuery(name="Loan.findAll", query="SELECT l FROM Loan l")
public class Loan implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name="LOAN_ID")
	private int loanId;

	@Column(name="INTEREST_RATE")
	private float interestRate;

	@Column(name="LOAN_AMOUNT")
	private double loanAmount;

	@Column(name="MAX_LOAN")
	private double maxLoan;

	@Column(updatable=false)
	private int tenure;

	//bi-directional one-to-one association to ProTable
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="PRO_ID")
	private Property property;

	public Loan() {
		System.out.println("loantable const() called...");
	}

	public int getLoanId() {
		return loanId;
	}

	public void setLoanId(int loanId) {
		this.loanId = loanId;
	}

	public float getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(float interestRate) {
		this.interestRate = interestRate;
	}
	public double getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}

	public double getMaxLoan() {
		return maxLoan;
	}

	public void setMaxLoan(double maxLoan) {
		this.maxLoan = maxLoan;
	}

	public int getTenure() {
		return tenure;
	}

	public void setTenure(int tenure) {
		this.tenure = tenure;
	}
	public Property getProperty() {
		return property;
	}

	public void setProperty(Property property) {
		this.property = property;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	

}