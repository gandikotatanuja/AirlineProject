package com.example.homeloan.layer2;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the LOANTRACKER_TABLE database table.
 * 
 */
@Entity
@Table(name="LOANTRACKER_TABLE")
@NamedQuery(name="LoanTracker.findAll", query="SELECT l FROM LoanTracker l")
public class LoanTracker implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name="FINAL_ID")
	private int finalId;

	@Column(name="ACC_NO")
	private double accNo;

	@Column(name="LOANAPP_ID")
	private int loanAppId;

	@Temporal(TemporalType.DATE)
	@Column(name="LOAN_APPROVAL_DATE")
	private Date loanApprovalDate;

	@ManyToOne
	@JoinColumn(name="DOC_ID")
	private Document document;

	public LoanTracker() {
		System.out.println("loantrackertable const() called...");
	}

	public int getFinalId() {
		return finalId;
	}

	public void setFinalId(int finalId) {
		this.finalId = finalId;
	}

	public double getAccNo() {
		return accNo;
	}

	public void setAccNo(double accNo) {
		this.accNo = accNo;
	}

	public int getLoanAppId() {
		return loanAppId;
	}

	public void setLoanAppId(int loanAppId) {
		this.loanAppId = loanAppId;
	}

	public Date getLoanApprovalDate() {
		return loanApprovalDate;
	}

	public void setLoanApprovalDate(Date loanApprovalDate) {
		this.loanApprovalDate = loanApprovalDate;
	}

	public Document getDocument() {
		return document;
	}

	public void setDocument(Document document) {
		this.document = document;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
	
}