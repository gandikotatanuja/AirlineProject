package com.example.homeloan.layer3;


import java.util.HashSet;
import java.util.Set;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.example.homeloan.layer2.UserRegistration;

@Repository
public class UserRegistrationRepoImpl implements UserRegistrationRepo {

	@PersistenceContext
	 EntityManager entityManager;
	
	@Transactional
	public void addUser(UserRegistration uRef) {
		entityManager.persist(uRef);

	}
	@Transactional
	public UserRegistration findUser(int uno)
	{
		System.out.println("user repo....NO scope of bussiness logic here...");
		return entityManager.find(UserRegistration.class,uno);
		
	}
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Transactional
	public Set<UserRegistration> findUsers()
	{
		Set<UserRegistration> userSet;
		userSet = new HashSet<UserRegistration>();
		String queryString = "from UserRegistration";
		Query query = entityManager.createQuery(queryString);	
		userSet = new HashSet(query.getResultList());
		return userSet;
	}
	
	@Transactional
	public void modifyUser(UserRegistration uRef) 
	{
		entityManager.merge(uRef);
	}
	@Transactional
	public void removeUser(int uno) 
	{
		UserRegistration dTemp = entityManager.find(UserRegistration.class,uno);
		entityManager.remove(dTemp);	
	}

}
