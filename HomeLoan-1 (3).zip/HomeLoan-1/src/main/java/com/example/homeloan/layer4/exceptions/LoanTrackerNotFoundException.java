package com.example.homeloan.layer4.exceptions;

@SuppressWarnings("serial")
public class LoanTrackerNotFoundException extends Exception {

	public LoanTrackerNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}