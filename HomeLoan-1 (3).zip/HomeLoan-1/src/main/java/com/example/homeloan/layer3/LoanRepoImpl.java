package com.example.homeloan.layer3;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.example.homeloan.layer2.Loan;



@Repository
public class LoanRepoImpl implements LoanRepo
{
    
	@PersistenceContext
	 EntityManager entityManager;
	
	@Transactional
	public void addLoan(Loan lRef) {
		entityManager.persist(lRef);

	}
	@Transactional
	public Loan findLoan(int lno) {
		System.out.println("Loan  repo....NO scope of bussiness logic here...");
		return entityManager.find(Loan.class,lno);
		
	}
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Transactional
	public Set<Loan> findLoans() {
		Set<Loan> LoanSet;
		LoanSet = new HashSet<Loan>();
		String queryString = "from Loan";
		Query query = entityManager.createQuery(queryString);
		LoanSet = new HashSet(query.getResultList());		
		return LoanSet;	
		
	}
	
	@Transactional
	public void modifyLoan(Loan lRef) {
		entityManager.merge(lRef);
	}
	@Transactional
	public void removeLoan(int lno) {
		Loan lTemp = entityManager.find(Loan.class,lno);
		entityManager.remove(lTemp);
	}
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Transactional
	public Set<Loan> findLoanByUserId(int lno) {
		Set<Loan> LoanSet;
		Query query = entityManager.createNativeQuery(" select * from loan_table where pro_id=(select pro_id from pro_table where income_id=(select income_id from income_table where user_id=101))",Loan.class);
		LoanSet = new HashSet(query.getResultList());
		return LoanSet;
		
	}
	
}