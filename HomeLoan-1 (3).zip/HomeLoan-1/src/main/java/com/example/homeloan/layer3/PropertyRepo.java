package com.example.homeloan.layer3;
import java.util.Set;

import org.springframework.stereotype.Repository;

import com.example.homeloan.layer2.Property;

@Repository
 public interface PropertyRepo
 {
	 	void addProperty(Property pRef);
		Property findProperty(int pno);			
		Set<Property> findPropertys();			
		void modifyProperty(Property pRef);
		void removeProperty(int pno);
		Set<Property> findPropertyByUserId(int i); 
}