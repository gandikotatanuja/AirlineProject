package com.example.homeloan.layer4;

import java.util.Set;

import org.springframework.stereotype.Service;

import com.example.homeloan.layer2.Property;
import com.example.homeloan.layer4.exceptions.PropertyAlreadyExsitException;
import com.example.homeloan.layer4.exceptions.PropertyNotFoundException;


@Service
 public interface PropertyService {
	    String addPropertyService(Property pRef) throws PropertyAlreadyExsitException;  //C - add/create;
		Property findPropertyService(int pno) throws PropertyNotFoundException ;			//  R - find - select					
		String modifyPropertyService(Property pRef)throws PropertyNotFoundException;		//  U - modify - update
		String removePropertyService(int pno) throws PropertyNotFoundException;
		Set<Property> findPropertiesService();
		//Set<ProTable> findProByUserId(int i); 
}