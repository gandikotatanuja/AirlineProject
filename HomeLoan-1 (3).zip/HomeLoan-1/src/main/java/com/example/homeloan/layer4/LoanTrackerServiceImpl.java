package com.example.homeloan.layer4;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.homeloan.layer2.LoanTracker;
import com.example.homeloan.layer3.LoanTrackerRepo;
import com.example.homeloan.layer4.exceptions.LoanTrackerAlreadyExsitException;
import com.example.homeloan.layer4.exceptions.LoanTrackerNotFoundException;


 @Service
public class LoanTrackerServiceImpl implements LoanTrackerService {

    	@Autowired	
    	LoanTrackerRepo  loanTrackerRepo;
   		@Override
		public String addLoanTrackerService(LoanTracker lRef) throws LoanTrackerAlreadyExsitException {
			
				System.out.println("LoanTracker Service....Some scope of bussiness logic here...");
				try {
					loanTrackerRepo.addLoanTracker(lRef);
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					throw new LoanTrackerAlreadyExsitException("LoanTracker Already Exsist");
				}
				return "LoanTracker added successfully";
			}
			
			

   		@Override
		public LoanTracker findLoanTrackerService(int lno) throws LoanTrackerNotFoundException {
				System.out.println("LoanTracker repo....NO scope of bussiness logic here...");
				LoanTracker loanTracker = loanTrackerRepo.findLoanTracker(lno);
				if(loanTracker == null) {
					throw new LoanTrackerNotFoundException("LoanTracker Not Found");
				}
				return loanTracker;
			}
			
	 
   		@Override
		public String modifyLoanTrackerService(LoanTracker lRef)throws LoanTrackerNotFoundException {
				LoanTracker loanTracker = loanTrackerRepo.findLoanTracker(lRef.getFinalId());
				if(loanTracker == null) {
					throw new LoanTrackerNotFoundException("LoanTracker Not Found");
					
				}
				else {
					loanTrackerRepo.modifyLoanTracker(lRef);
				}
			
			return "LoanTracker modifed successfully";
        }

		@Override
		public String removeLoanTrackerService(int lno)throws LoanTrackerNotFoundException {
				LoanTracker loanTracker = loanTrackerRepo.findLoanTracker(lno);
				if(loanTracker == null) {
					throw new LoanTrackerNotFoundException("LoanTracker Not Found");
					
				}
				else {
					loanTrackerRepo.removeLoanTracker(lno);
				}
					
			return "LoanTracker Deleted successfully";

		  }



		@Override
		public Set<LoanTracker> findLoanTrackersService() {
			
			return loanTrackerRepo.findLoanTrackers();
		}
		
   		
	

	}

