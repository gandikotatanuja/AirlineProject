package com.example.homeloan.layer3;


import java.util.Set;

import org.springframework.stereotype.Repository;

import com.example.homeloan.layer2.LoanTracker;

@Repository
public interface LoanTrackerRepo {

	void addLoanTracker(LoanTracker lRef);		//	C - add - insert
	LoanTracker findLoanTracker(int lno);			//  R - find - select
	Set<LoanTracker> findLoanTrackers();			//  R - find - select all
	void modifyLoanTracker(LoanTracker lRef);		//  U - modify - update
	void removeLoanTracker(int lno);
	Set<LoanTracker> findLoanAppIdByUserId(int i);
}