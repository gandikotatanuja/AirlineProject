package com.example.homeloan.layer3;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.example.homeloan.layer2.Income;


	@Repository
	public class IncomeRepoImpl implements IncomeRepo {

		@PersistenceContext
		 EntityManager entityManager;//auto injected by spring by reading 
											//persistance.xml file
		@Transactional
		public void addIncome(Income iref) {
			System.out.println("add Income started..");
			entityManager.persist(iref);

		}
		@Transactional
		public Income findIncome(int ino) {
			
			System.out.println("Income repo....NO scope of bussiness logic here...");
			return entityManager.find(Income.class,ino);
		}

		@SuppressWarnings({ "rawtypes", "unchecked" })
		@Transactional
		public Set<Income> findIncomes() {
			Set<Income> incomeSet;
			incomeSet = new HashSet<Income>();
			String queryString = "from Income";
			Query query = entityManager.createQuery(queryString);
			incomeSet = new HashSet(query.getResultList());			
			return incomeSet;
		}
		@Transactional
		public void modifyIncome(Income iref) {
			
			entityManager.merge(iref);
		}
		@Transactional
		public void removeIncome(int ino) {
			Income iTemp = entityManager.find(Income.class,ino);
			entityManager.remove(iTemp);

		}
		@SuppressWarnings({ "rawtypes", "unchecked" })
		@Transactional
		public Set<Income> findIncomeByUserId(int ino) 
		{
			Set<Income> incomeSet;
			Query query = entityManager.createQuery("from Income e where user_id =:myno",Income.class).setParameter("myno", ino);
			incomeSet = new HashSet(query.getResultList());	
			return incomeSet;
		}
	}