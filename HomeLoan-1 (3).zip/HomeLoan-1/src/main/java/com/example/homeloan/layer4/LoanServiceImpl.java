package com.example.homeloan.layer4;

import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.homeloan.layer2.Loan;
import com.example.homeloan.layer3.LoanRepo;
import com.example.homeloan.layer4.exceptions.LoanAlreadyExistException;
import com.example.homeloan.layer4.exceptions.LoanNotFoundException;

@Service
public class LoanServiceImpl implements LoanService {
	@Autowired
	LoanRepo loanRepo;
			
	@Override
	public String addLoanService(Loan lRef) throws LoanAlreadyExistException {
		System.out.println("Loan Service....Some scope of bussiness logic here...");
		try {
			loanRepo.addLoan(lRef);	
		} 
		catch (Exception e) {
			throw new LoanAlreadyExistException("Loan Already Exist");
		}
		return "Loan added successfully";
		}
	@Override
	public Loan findLoanService(int lno) throws LoanNotFoundException {
		
		System.out.println("Loan Service....Some scope of bussiness logic here...");
		Loan loan = loanRepo.findLoan(lno);
		if(loan == null)
		{
			throw new LoanNotFoundException("Loan Not Found");
		}
		return loan;
		}
	
	@Override
	public String modifyLoanService(Loan lRef) throws LoanNotFoundException {
		Loan loan = loanRepo.findLoan(lRef.getLoanId());
		if(loan == null)
		{
			throw new LoanNotFoundException("Loan Not Found");
		}
		else {
			loanRepo.modifyLoan(lRef);
		}	
		return "Loan modifed successfully";
		}
	@Override
	public String removeLoanService(int lno) throws LoanNotFoundException{
		Loan loan = loanRepo.findLoan(lno);
		if(loan == null) 
		{
			throw new LoanNotFoundException("Loan Not Found");
		}
		else
		{
		loanRepo.removeLoan(lno);
		}			
		return "Loan Deleted successfully";
		}
	@Override
	public Set<Loan> findLoansService() {
		System.out.println("Loan Service....Some scope of bussiness logic here...");
		return loanRepo.findLoans();
	}
	
}
