package com.example.homeloan.layer2;
import java.io.Serializable;
import java.util.Set;

import javax.persistence.*;


/**
 * The persistent class for the PRO_TABLE database table.
 * 
 */
@Entity
@Table(name="PRO_TABLE")
@NamedQuery(name="Property.findAll", query="SELECT p FROM Property p")
public class Property implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name="PRO_ID")
	private int proId;

	@Column(name="ESTIMATED_AMT")
	private double estimatedAmt;

	@Column(name="PROPERTY_LOC")
	private String propertyLoc;

	@Column(name="PROPERTY_NAME")
	private String propertyName;

	@Column(name="PROPERTY_TYPE")
	private String propertyType;

	//bi-directional many-to-one association to IncomeTable
	@ManyToOne
	@JoinColumn(name="INCOME_ID")
	private Income income;

	//bi-directional one-to-one association to LoanTable
	@OneToMany(mappedBy="property", fetch=FetchType.EAGER)
	private Set<Loan> loan;

	public Property() {
		System.out.println("protable const() called...");
	}

	public int getProId() {
		return proId;
	}

	public void setProId(int proId) {
		this.proId = proId;
	}

	public double getEstimatedAmt() {
		return estimatedAmt;
	}

	public void setEstimatedAmt(double estimatedAmt) {
		this.estimatedAmt = estimatedAmt;
	}

	public String getPropertyLoc() {
		return propertyLoc;
	}

	public void setPropertyLoc(String propertyLoc) {
		this.propertyLoc = propertyLoc;
	}

	public String getPropertyName() {
		return propertyName;
	}

	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}

	public String getPropertyType() {
		return propertyType;
	}

	public void setPropertyType(String propertyType) {
		this.propertyType = propertyType;
	}

	public Income getIncome() {
		return income;
	}

	public void setIncome(Income income) {
		this.income = income;
	}

	
	public Set<Loan> getLoan() {
		return loan;
	}

	public void setLoan(Set<Loan> loan) {
		this.loan = loan;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
}