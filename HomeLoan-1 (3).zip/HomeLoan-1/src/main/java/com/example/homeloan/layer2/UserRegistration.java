package com.example.homeloan.layer2;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the USERREGISTRATION database table.
 * 
 */
@Entity
@Table(name="USER_TABLE")
@NamedQuery(name="UserRegistration.findAll", query="SELECT u FROM UserRegistration u")
public class UserRegistration implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name="USER_ID")
	private int userId;

	private String address;

	@Column(name="ADHAR_NO")
	private long adharNo;

	@Column(name="CONFIRM_PASSWORD")
	private String confirmPassword;

	@Temporal(TemporalType.DATE)
	private Date dob;

	private String fname;

	private String gender;

	private String lname;

	private String mailid;

	private String mname;

	private String nationality;

	@Column(name="PAN_NO")
	private String panNo;

	private String password;

	private long phoneno;

	//bi-directional many-to-one association to Document
	@OneToMany(mappedBy="userRegistration", fetch=FetchType.EAGER,cascade = CascadeType.ALL)
	private Set<Document> document;

	//bi-directional many-to-one association to Income
	@OneToMany(mappedBy="userRegistration", fetch=FetchType.EAGER,cascade = CascadeType.ALL)
	private Set<Income> income;

	public UserRegistration() {
	}

	public int getUserId() {
		return this.userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public long getAdharNo() {
		return this.adharNo;
	}

	public void setAdharNo(long adharNo) {
		this.adharNo = adharNo;
	}

	public String getConfirmPassword() {
		return this.confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public Date getDob() {
		return this.dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getFname() {
		return this.fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getGender() {
		return this.gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getLname() {
		return this.lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getMailid() {
		return this.mailid;
	}

	public void setMailid(String mailid) {
		this.mailid = mailid;
	}

	public String getMname() {
		return this.mname;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public String getNationality() {
		return this.nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getPanNo() {
		return this.panNo;
	}

	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public long getPhoneno() {
		return this.phoneno;
	}

	public void setPhoneno(long phoneno) {
		this.phoneno = phoneno;
	}
    
	@JsonIgnore
	public Set<Document> getDocument() {
		return this.document;
	}

	public void setDocument(Set<Document> document) {
		this.document = document;
	}

	public Document addDocument(Document document) {
		getDocument().add(document);
		document.setUserRegistration(this);

		return document;
	}

	public Document removeDocument(Document document) {
		getDocument().remove(document);
		document.setUserRegistration(null);

		return document;
	}

	public Set<Income> getIncome() {
		return this.income;
	}

	public void setIncome(Set<Income> income) {
		this.income= income;
	}

	public Income addIncome(Income income) {
		getIncome().add(income);

		return income;
	}

	public Income removeIncome(Income income) {
		getIncome().remove(income);
		income.setUserRegistration(null);

		return income;
	}

}