package com.example.homeloan.layer5;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

//import org.springframework.web.bind.annotation.*;
//import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.ResponseEntity.HeadersBuilder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.homeloan.layer2.Property;
import com.example.homeloan.layer4.PropertyService;
import com.example.homeloan.layer4.exceptions.PropertyAlreadyExsitException;
import com.example.homeloan.layer4.exceptions.PropertyNotFoundException;

@RestController  //REpresentational State Transfer html xml json
public class PropertyController {

	@Autowired
	PropertyService propertyServ;
	
	@GetMapping(path="/getProperty/{mypno}") //Get Request in Postman http://localhost:8080/getLoan/1
	@ResponseBody
	public ResponseEntity<Property> getProperty(@PathVariable("mypno") Integer lno) throws PropertyNotFoundException  {
		System.out.println("Property Controller....Understanding client and talking to service layer...");
		Property property = null;
		property =propertyServ.findPropertyService(lno);
			if(property == null) {
				Map m = new HashMap();
				m.put("message",  "Property Not found");
				//HeadersBuilder hb = ResponseEntity.notFound();
				
				HttpStatus status =HttpStatus.NOT_FOUND;
				//return new ResponseEntity(m,status);
				return ResponseEntity.notFound().build();
				//return new 
				
			}
			else {
				return ResponseEntity.ok(property);
			}
	}
	
	
	@GetMapping(path="/getProperties")
	@ResponseBody
	public Set<Property> getAllProperties() {
		System.out.println("Property Controller....Understanding client and talking to service layer...");
		Set<Property> propertyList = propertyServ.findPropertiesService();
		return propertyList;
		
	}
	
	@PostMapping(path="/addProperty")
	public String addProperty(@RequestBody Property property) {
		
		String statusMsg = null;
		try {
			statusMsg =propertyServ.addPropertyService(property);
		} catch (PropertyAlreadyExsitException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return e.getMessage();
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return statusMsg;
		
	}
	
	@PutMapping(path="/modifyProperty")
	public String modifyProperty(@RequestBody Property property) {
		String statusMsg = null;
		try {
			statusMsg = propertyServ.modifyPropertyService(property);
		} catch (PropertyNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			return e.getMessage();
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return statusMsg;
		
	}
	
	@DeleteMapping(path="/deleteProperty")
	public String deleteProperty(@RequestBody Property property ) {
		String statusMsg = null;
		try {
			statusMsg = propertyServ.removePropertyService(property.getProId());
		} catch (PropertyNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			return e.getMessage();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return statusMsg;
		
	}
	
}
