package com.example.homeloan;

import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import com.example.homeloan.layer2.Income;
import com.example.homeloan.layer2.Property;
import com.example.homeloan.layer3.IncomeRepo;
import com.example.homeloan.layer3.PropertyRepo;

@SpringBootTest
public class ProTableTest {
	@Autowired
	PropertyRepo propertyRepo;
	@Autowired
	IncomeRepo incomeRepo;
	
	@Test
	public void testInsertNewPro() {//success
		Property property = new Property();
		
		property.setPropertyLoc("ViZAG");
		property.setPropertyName("KRISHNA");
		property.setPropertyType("Plot");
		property.setEstimatedAmt(1600000);
		Income income=incomeRepo.findIncome(124);  
		property.setIncome(income);
		propertyRepo.addProperty(property);
	}
	@Test
	public void testModifyProperty() 
	{                                  //success
		Property property = new Property();
		Income income=incomeRepo.findIncome(124);  
		propertyRepo.findProperty(132); 
		property.setProId(132);
		property.setPropertyLoc("VIZAG");
		property.setPropertyName("RadhaKrishna");
		property.setPropertyType("PLOT");
		property.setEstimatedAmt(1600000);
		property.setIncome(income);
		propertyRepo.modifyProperty(property);

	}
	@Test
	public void testRemoveProperty() {//success//DBT
		propertyRepo.removeProperty(601);
		
	}
	@Test
	public void testFindProperty() {//sucess
		Property property=propertyRepo.findProperty(603);
		System.out.println(property.getProId());
		System.out.println(property.getPropertyLoc());
		System.out.println(property.getPropertyName());
		System.out.println(property.getPropertyType());
		System.out.println(property.getEstimatedAmt());
		System.out.println(property.getIncome().getIncomeId());
		
		System.out.println("-----------------");
	}
	@Test
	public void testFindAllProperty() { //success
		Set<Property> proSet = propertyRepo.findPropertys();
		for (Property property: proSet) {
			System.out.println(property.getProId());
			System.out.println(property.getPropertyLoc());
			System.out.println(property.getPropertyName());
			System.out.println(property.getPropertyType());
			System.out.println(property.getEstimatedAmt());
			System.out.println(property.getIncome().getIncomeId());
			
			System.out.println("-----------------");
		}
	}

}
