package com.example.homeloan;

import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.homeloan.layer2.Income;
import com.example.homeloan.layer2.UserRegistration;
import com.example.homeloan.layer3.IncomeRepo;
import com.example.homeloan.layer3.UserRegistrationRepo;

@SpringBootTest
public class IncomeTableTestCase {

	@Autowired
	IncomeRepo incomeRepo;
	
	@Autowired
	UserRegistrationRepo userRepo;
	

	@Test
	public void testIncomeInsert() { //success
		Income income=new Income();
		income.setTypeOfEmp("SALARIED");
		income.setRetirementAge(65);
		income.setOrganizationType("g");
		income.setEmployerName("krishna"); 
		UserRegistration user=userRepo.findUser(101); 
		income.setUserRegistration(user);
		incomeRepo.addIncome(income);
			
	}
	@Test
	public void testIncomedelete()//dbt
	{//success
		incomeRepo.removeIncome(124);		
	}

	
	@Test
	public void testIncomeModify() //success
	{
	Income income=new Income();
	UserRegistration user=userRepo.findUser(101);  
	incomeRepo.findIncome(124); 
	income.setIncomeId(124);
	income.setTypeOfEmp("SELF-EMPLOYED");
	income.setRetirementAge(66);
	income.setOrganizationType("l12");
	income.setEmployerName("Mohan");
	income.setUserRegistration(user);
	incomeRepo.modifyIncome(income);
	
	}
	
	@Test
	public void testIncomefind() {//success
	Income income=incomeRepo.findIncome(203);
	System.out.println(income.getIncomeId());
	System.out.println(income.getTypeOfEmp());
	System.out.println(income.getOrganizationType());
	System.out.println(income.getRetirementAge());
	System.out.println(income.getUserRegistration().getUserId());
	
	
	}
	
	
	
	@Test
	public void testIncomefindAll() //success
	{ 
		Set<Income> incomeSet=incomeRepo.findIncomes();		
		for(Income income:incomeSet) {
		System.out.println(income.getIncomeId());
		System.out.println(income.getTypeOfEmp());
		System.out.println(income.getOrganizationType());
		System.out.println(income.getRetirementAge());
		System.out.println(income.getUserRegistration().getUserId());
		
		
		}
	}
	
}
