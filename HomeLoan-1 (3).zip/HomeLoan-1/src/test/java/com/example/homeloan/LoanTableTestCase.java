package com.example.homeloan;

import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.homeloan.layer2.Loan;
import com.example.homeloan.layer2.Property;
import com.example.homeloan.layer3.LoanRepo;
import com.example.homeloan.layer3.PropertyRepo;

@SpringBootTest
public class LoanTableTestCase {

	@Autowired
	LoanRepo loanRepo;
	
	@Autowired
	PropertyRepo propertyRepo;
	
	@Test
	public void testInsertNewLoan() {//success//dbt
		
		Loan loan = new Loan();
		loan.setMaxLoan(30000000);
		loan.setInterestRate(15.25f);
		loan.setTenure(220);
		loan.setLoanAmount(160000000);
		//Property pro=propertyRepo.findProperty(601);
		//loan.setProperty(pro);
		loanRepo.addLoan(loan);
	}
	@Test
	public void testLoanModify() { //success
		Loan loan = new Loan();
		Property pro=propertyRepo.findProperty(605);  
		loanRepo.findLoan(131); 
		loan.setLoanId(131);
		loan.setMaxLoan(200000000);
		loan.setInterestRate(12.25f);
		loan.setTenure(120);
		loan.setLoanAmount(16000000);
		loan.setProperty(pro);
		loanRepo.modifyLoan(loan);
		
	}
		

	@Test
	public void testRemoveLoan() {//success
		loanRepo.removeLoan(301);
		
	}

	@Test
	public void testFindLoan() {//success
		Loan loan=loanRepo.findLoan(303);
		System.out.println(loan.getLoanId());
		System.out.println(loan.getMaxLoan());
		System.out.println(loan.getInterestRate());
		System.out.println(loan.getTenure());
		System.out.println(loan.getProperty().getProId());
		System.out.println("-----------------");
		
	}
	
	
	@Test
	public void testFindAllloan() {//success
		Set<Loan> loanSet = loanRepo.findLoans();
		for (Loan loan: loanSet) {
			System.out.println(loan.getLoanId());
			System.out.println(loan.getMaxLoan());
			System.out.println(loan.getInterestRate());
			System.out.println(loan.getTenure());
			System.out.println(loan.getProperty().getProId());
			System.out.println("-----------------");
		}
	}
	
	
}
