package com.example.homeloan;

import java.sql.Date;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.homeloan.layer2.Document;
import com.example.homeloan.layer2.LoanTracker;
import com.example.homeloan.layer3.DocumentRepo;
import com.example.homeloan.layer3.LoanTrackerRepo;

@SpringBootTest
public class LoanTrackerTableTestCase {
	@Autowired
	LoanTrackerRepo loanTrackerRepo;
	@Autowired
	DocumentRepo docRepo;
	
	@Test
	public void testLoanTrackerInsert() {//success
	LoanTracker loanTracker=new LoanTracker();
	String str2="1996-08-15";
	Date date2=Date.valueOf(str2);
	loanTracker.setLoanApprovalDate(date2);
	loanTracker.setAccNo(1524789365);
	loanTracker.setLoanAppId(10006);
	Document doc=docRepo.findDocument(122); 
	loanTracker.setDocument(doc);
	loanTrackerRepo.addLoanTracker(loanTracker);
	
	}
	
	@Test
	public void testLoanTrackerDelete() {//success//dbt
		loanTrackerRepo.removeLoanTracker(803);
	}
	@Test
	public void testLoanTrackerModify() {//SUCCESS
	LoanTracker loanTracker=new LoanTracker();
	Document doc=docRepo.findDocument(704);  
	loanTrackerRepo.findLoanTracker(803); 
	loanTracker.setFinalId(803);
	String str2="1996-08-15";
	 Date date2=Date.valueOf(str2);
	loanTracker.setLoanApprovalDate(date2);
	loanTracker.setLoanAppId(10005);
	loanTracker.setAccNo(952147823);
	loanTracker.setDocument(doc);
	loanTrackerRepo.modifyLoanTracker(loanTracker);
	}
	
	@Test
	public void testLoanTrackerFindAll() {//success
	Set<LoanTracker> lSet=loanTrackerRepo.findLoanTrackers();		
	for(LoanTracker loanTracker:lSet) {
		System.out.println(loanTracker.getAccNo());
		System.out.println(loanTracker.getFinalId());
		System.out.println(loanTracker.getLoanAppId());
		System.out.println(loanTracker.getLoanApprovalDate());
		System.out.println(loanTracker.getDocument().getDocId());
		
	}
	}
	
	@Test
	public void testLoanTrackerFind() {//sucess
		LoanTracker loanTracker=loanTrackerRepo.findLoanTracker(802);
		System.out.println(loanTracker.getLoanApprovalDate());
		System.out.println(loanTracker.getLoanAppId());
		System.out.println(loanTracker.getAccNo());
		System.out.println(loanTracker.getDocument().getDocId());
		
		
		System.out.println("-----------------");
	}
	
}

