package com.example.homeloan;

import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.homeloan.layer2.Document;
import com.example.homeloan.layer2.Income;
import com.example.homeloan.layer2.Loan;
import com.example.homeloan.layer2.LoanTracker;
import com.example.homeloan.layer2.Property;
import com.example.homeloan.layer3.DocumentRepo;
import com.example.homeloan.layer3.IncomeRepo;
import com.example.homeloan.layer3.LoanRepo;
import com.example.homeloan.layer3.LoanTrackerRepo;
import com.example.homeloan.layer3.PropertyRepo;


@SpringBootTest
public class BussinessTestCases {
	@Autowired
	DocumentRepo docRepo;
	@Autowired
	LoanTrackerRepo loanTrackerRepo;
	@Autowired
	IncomeRepo incomeRepo;
	@Autowired
	PropertyRepo propertyRepo;
	@Autowired
	LoanRepo loanRepo;
	@Test
	void DocumentByUserId() {//Success
		Set<Document> documentSet = docRepo.findDocumentByUserId(101);
		for (Document doc: documentSet ) {
			System.out.println(doc.getDocId());
			System.out.println(doc.getPanCard());
			System.out.println(doc.getVoterId());
			System.out.println(doc.getSalaryslip());
			System.out.println(doc.getLoa());
			System.out.println(doc.getNoc());
			System.out.println(doc.getAgreement());
			System.out.println(doc.getUserRegistration().getUserId());
			System.out.println("-----------------");
		}
	}
		@Test
		void LoanTrackerByUserId() {//success
			Set<LoanTracker> loanSet = loanTrackerRepo.findLoanAppIdByUserId(101);
			for (LoanTracker loan: loanSet) {
				System.out.println(loan.getFinalId());
				System.out.println(loan.getAccNo());
				System.out.println(loan.getLoanAppId());
				System.out.println(loan.getLoanApprovalDate());
				System.out.println(loan.getDocument().getDocId());
				System.out.println("-----------------");
			}
		}
		@Test
		void IncomeByUserId() {//success
			Set<Income> incomeSet = incomeRepo.findIncomeByUserId(101);
			for (Income income: incomeSet) {
				System.out.println(income.getIncomeId());
				System.out.println(income.getTypeOfEmp());
				System.out.println(income.getOrganizationType());
				System.out.println(income.getRetirementAge());
				System.out.println(income.getUserRegistration().getUserId());
				System.out.println("-----------------");
			}
		}
		@Test
		void PropertyByUserId() {//sucess
			Set<Property> propertySet = propertyRepo.findPropertyByUserId(101);
			for (Property property: propertySet ) {
				System.out.println(property.getProId());
				System.out.println(property.getPropertyLoc());
				System.out.println(property.getPropertyName());
				System.out.println(property.getPropertyType());
				System.out.println(property.getEstimatedAmt());
				System.out.println(property.getIncome().getIncomeId());
				System.out.println("-----------------");
			}
		}
		@Test
		void LoanByUserId() {	//Success
			Set<Loan> lSet = loanRepo.findLoanByUserId(101);
			for (Loan loan: lSet) {
				System.out.println(loan.getLoanId());
				System.out.println(loan.getMaxLoan());
				System.out.println(loan.getMaxLoan());
				System.out.println(loan.getTenure());
				System.out.println(loan.getInterestRate());
				System.out.println(loan.getLoanAmount());
				System.out.println(loan.getProperty().getProId());
				System.out.println("-----------------");
			}
		}
		
		
		
		
		
}