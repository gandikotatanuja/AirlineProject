package com.example.homeloan;

import java.sql.Date;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.homeloan.layer2.UserRegistration;
import com.example.homeloan.layer3.UserRegistrationRepo;


@SpringBootTest
 class UserTableTest {
	
	@Autowired
	UserRegistrationRepo userRepo;
	
	@Test
	public void testInsertNewUser() {  //succes
		UserRegistration user = new UserRegistration();
		
		user.setFname("radha");
		user.setMname("krishna");
		user.setLname("g");
		user.setMailid("rki@gmail.com");
		user.setPassword("123@asg");
		user.setConfirmPassword("123@asg");
		user.setAddress("ap");
		user.setPhoneno((long) 1254126398);
		String str2="1996-08-15";
	    Date date2=Date.valueOf(str2);
		user.setDob(date2);
		user.setGender("male");
		user.setNationality("indian");
		user.setAdharNo(1254126398);
		user.setPanNo("clap1234");
		userRepo.addUser(user);
			
	}
	@Test
	public void testModify() {//success
		UserRegistration user = new UserRegistration();
		   
		user.setUserId(88);
		user.setFname("RADHA");
		user.setMname("KRISHNA");
		user.setLname("g");
		user.setMailid("r@gmail.com");
		user.setPassword("1234@asg");
		user.setConfirmPassword("1234@asg");
		user.setAddress("ts");
		user.setPhoneno((long) 1254126398);
		 String str2="1996-08-15";
		 Date date2=Date.valueOf(str2);
		user.setDob(date2);
		user.setGender("male");
		user.setNationality("indian");
		user.setAdharNo(1254126398);
		user.setPanNo("clap1235");
		userRepo.modifyUser(user);
		
		
	}
	@Test
	public void testRemove() 
	{//success
		userRepo.removeUser(44);	
	}
	@Test
	public void testUserFind() 
	{ //success

		UserRegistration user=userRepo.findUser(105);
			System.out.println(user.getUserId());
			System.out.println(user.getFname());
			System.out.println(user.getMname());
			System.out.println(user.getLname());
			System.out.println(user.getMailid());
			System.out.println(user.getPassword());
			System.out.println(user.getConfirmPassword());
			System.out.println(user.getAddress());
			System.out.println(user.getDob());
			System.out.println(user.getGender());
			System.out.println(user.getPhoneno());
			System.out.println(user.getNationality());
			System.out.println(user.getAdharNo());
			System.out.println(user.getPanNo());
			System.out.println("-----------------");

	}
	@Test
	public void testFindAll() 
	{//success
		
		Set<UserRegistration> userlist = userRepo.findUsers();
		for (UserRegistration user: userlist) 
		{
			    System.out.println(user.getUserId());
				System.out.println(user.getFname());
				System.out.println(user.getMname());
				System.out.println(user.getLname());
				System.out.println(user.getMailid());
				System.out.println(user.getPassword());
				System.out.println(user.getConfirmPassword());
				System.out.println(user.getAddress());
				System.out.println(user.getDob());
				System.out.println(user.getGender());
				System.out.println(user.getPhoneno());
				System.out.println(user.getNationality());
				System.out.println(user.getAdharNo());
				System.out.println(user.getPanNo());
				System.out.println("-----------------");
		}
	
	}
}
