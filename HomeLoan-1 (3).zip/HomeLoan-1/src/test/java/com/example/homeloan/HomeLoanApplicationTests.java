package com.example.homeloan;

import java.sql.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.homeloan.layer2.Document;
import com.example.homeloan.layer2.Income;
import com.example.homeloan.layer2.Loan;
import com.example.homeloan.layer2.LoanTracker;
import com.example.homeloan.layer2.Property;
import com.example.homeloan.layer2.User;
import com.example.homeloan.layer3.DocumentRepo;
import com.example.homeloan.layer3.IncomeRepo;
import com.example.homeloan.layer3.LoanRepo;
import com.example.homeloan.layer3.LoanTrackerRepo;
import com.example.homeloan.layer3.PropertyRepo;
import com.example.homeloan.layer3.UserRepo;

@SpringBootTest
class HomeLoanApplicationTests {
	
	@Autowired
	UserRepo uri;
	
	@Autowired
	LoanRepo lri;
	
	@Autowired
	IncomeRepo iri;
	
	@Autowired
	DocumentRepo dri1;
	
	@Autowired
	PropertyRepo pri;
	
	@Autowired
	LoanTrackerRepo ltr;
	
	
	@Test
	public void testInsertNewUser() {  //succes
		User user = new User();
		
		user.setFname("radha");
		user.setMname("krishna");
		user.setLname("g");
		user.setMailid("riiik@gmail.com");
		user.setPassword("123@asg");
		user.setConfirmPassword("123@asg");
		user.setAddress("ap");
		user.setPhoneno((long) 1254126398);
		 String str2="1996-08-15";
		 Date date2=Date.valueOf(str2);
		user.setDob(date2);
		user.setGender("male");
		user.setNationality("indian");
		user.setAdharNo(1254126398);
		user.setPanNo("clap1234");
		uri.addUser(user);
			
	}
	@Test
	public void testModify() {
		User user = new User();

		user.setFname("radha");
		user.setMname("krishna");
		user.setLname("g");
		user.setMailid("r@gmail.com");
		user.setPassword("1234@asg");
		user.setConfirmPassword("1234@asg");
		user.setAddress("ap");
		user.setPhoneno((long) 1254126398);
		 String str2="1996-08-15";
		 Date date2=Date.valueOf(str2);
		user.setDob(date2);
		user.setGender("male");
		user.setNationality("indian");
		user.setAdharNo(1254126398);
		user.setPanNo("clap1235");
		uri.modifyUser(user);
		
		
	}
	@Test
	public void testRemove() {//success
		
		uri.removeUser(44);
		
		
		
	}
	@Test
	public void testUserFind() { //success

	   User d=uri.findUser(105);
	   System.out.println(d.getUserId());
		System.out.println(d.getFname());
		System.out.println(d.getMname());
		System.out.println(d.getLname());
		System.out.println(d.getMailid());
		System.out.println(d.getPassword());
		System.out.println(d.getConfirmPassword());
		System.out.println(d.getAddress());
		System.out.println(d.getDob());
		System.out.println(d.getGender());
		System.out.println(d.getPhoneno());
		System.out.println(d.getNationality());
		System.out.println(d.getAdharNo());
		System.out.println(d.getPanNo());
		System.out.println("-----------------");

	}
	@Test
	public void testFindAll() {//success
		
		List<User> userlist = uri.findUsers();
		for (User d: userlist) {
			System.out.println(d.getUserId());
			System.out.println(d.getFname());
			System.out.println(d.getMname());
			System.out.println(d.getLname());
			System.out.println(d.getMailid());
			System.out.println(d.getPassword());
			System.out.println(d.getConfirmPassword());
			System.out.println(d.getAddress());
			System.out.println(d.getDob());
			System.out.println(d.getGender());
			System.out.println(d.getPhoneno());
			System.out.println(d.getNationality());
			System.out.println(d.getAdharNo());
			System.out.println(d.getPanNo());
			System.out.println("-----------------");
		}
	
		
	}
	
	
	@Test
	public void testInsertNewLoan() {//success
		Loan loan = new Loan();
		loan.setLoanId(301);
		loan.setMaxLoan(200000);
		loan.setInterestRate(11.25f);
		loan.setTenure(120);
		loan.setLoanAmount(15000000);
	
		lri.addLoan(loan);
	}
	@Test
	public void testModify1() {
		Loan loan = new Loan();
		loan.setLoanId(301);
		loan.setMaxLoan(200000);
		loan.setInterestRate(12.25f);
		loan.setTenure(120);
		loan.setLoanAmount(15000000);
		lri.modifyLoan(loan);
		
	}
		

	@Test
	public void testRemoveLoan() {//success
		lri.removeLoan(301);
		
	}

	@Test
	public void testFindLoan() {//success
		Loan l=lri.findLoan(303);
		System.out.println(l.getLoanId());
		System.out.println(l.getMaxLoan());
		System.out.println(l.getInterestRate());
		System.out.println(l.getTenure());
		
		System.out.println("-----------------");
		
	}
	
	
	@Test
	public void testFindAllloan() {//success
		List<Loan> loanlist = lri.findLoans();
		for (Loan l: loanlist) {
			System.out.println(l.getLoanId());
			System.out.println(l.getMaxLoan());
			System.out.println(l.getInterestRate());
			System.out.println(l.getTenure());
			System.out.println(l.getProTable());
			System.out.println("-----------------");
		}
	}
	
	
	@Test
	public void testIncomeInsert() { //success
	Income it=new Income();
	
		it.setTypeOfEmp("SALARIED");
		it.setRetirementAge(65);
		it.setOrganizationType("g");
		it.setEmployerName("krishna");
		iri.addIncome(it);
			
	}


	
	@Test
	public void testIncomedelete() {//success
	Income it=new Income();
		iri.removeIncome(54);
			
	}

	
	@Test
	public void testIncomeModify() {
	Income it=new Income();
	
	it.setTypeOfEmp("SELF-EMPLOYED");
	it.setRetirementAge(66);
	it.setOrganizationType("l");
	it.setEmployerName("Mohan");
	
	
	iri.modifyIncome(it);
	
	}
	
	
	
	
	@Test
	public void testIncomefind() {//success
	Income it=iri.findIncome(203);
	System.out.println(it.getIncomeId());
	System.out.println(it.getTypeOfEmp());
	System.out.println(it.getOrganizationType());
	System.out.println(it.getRetirementAge());
	System.out.println(it.getUserTable());
	
	}
	
	
	
	@Test
	public void testIncomefindAll() { //success
		List<Income> ilist=iri.findIncomes();		
		Income it=new Income();
		for(Income i:ilist) {
		System.out.println(i.getIncomeId());
		System.out.println(i.getTypeOfEmp());
		System.out.println(i.getOrganizationType());
		System.out.println(i.getRetirementAge());
		System.out.println(i.getUserTable());
		
		
		}

	
	}
	
	
	@Test
	public void testInsertNewDoc() {//success
		Document doc = new Document();
		
		doc.setPanCard("Uploaded");
		doc.setVoterId("Submitted");
		doc.setSalaryslip("Uploaded");
		doc.setLoa("Completed");
		doc.setNoc("Submitted");
		doc.setAgreement("Submitted");
		
		dri1.addDocument(doc);
		
	}
	@Test
	public void testModifyDoc() {
		Document doc = new Document();
		  
		dri1.findDocTable(68); 
		doc.setDocId(68);
		doc.setPanCard("Uploaded");
		doc.setVoterId("notsubmitted");
		doc.setSalaryslip("Uploaded");
		doc.setLoa("Completed");
		doc.setNoc("Submitted");
		doc.setAgreement("Not Submitted");
		//d.getUserTable().getUserId()
		
		dri1.modifyDocTable(doc);
		
	}
	@Test
	public void testRemoveDoc() {//success
		dri1.removeDocTable(59);
		
	}
	@Test
	public void testFindDoc() {//success
		Document d=dri1.findDocTable(703);
		System.out.println(d.getDocId());
		System.out.println(d.getPanCard());
		System.out.println(d.getVoterId());
		System.out.println(d.getSalaryslip());
		System.out.println(d.getLoa());
		System.out.println(d.getNoc());
		System.out.println(d.getAgreement());
		System.out.println("-----------------");
	
	}
	@Test
	public void testFindAllDoc() {//success
		List<Document> doclist = dri1.findDocTables();
		for (Document d: doclist) {
			System.out.println(d.getDocId());
			System.out.println(d.getPanCard());
			System.out.println(d.getVoterId());
			System.out.println(d.getSalaryslip());
			System.out.println(d.getLoa());
			System.out.println(d.getNoc());
			System.out.println(d.getAgreement());
			System.out.println("-----------------");
		}
		
	
}
	
	
	@Test
	public void testInsertNewPro() {
		Property pro = new Property();
		
		pro.setPropertyLoc("ViZAG");
		pro.setPropertyName("KRISHNA");
		pro.setPropertyType("Plot");
		pro.setEstimatedAmt(1600000);
		//pro.setIncomeTable(201);
		
		pri.addProTable(pro);
	}
	@Test
	public void testModifyPro() {
		Property pro = new Property();
	
		pro.setPropertyLoc("ViZAG");
		pro.setPropertyName("RadhaKrishna");
		pro.setPropertyType("Plot");
		pro.setEstimatedAmt(1600000);
		pri.addProTable(pro);

	}
	@Test
	public void testRemovePro() {//sucess
		pri.removeProTable(601);
		
	}
	@Test
	public void testFindPro() {//sucess
		Property p=pri.findProTable(603);
		System.out.println(p.getProId());
		System.out.println(p.getPropertyLoc());
		System.out.println(p.getPropertyName());
		System.out.println(p.getPropertyType());
		System.out.println(p.getEstimatedAmt());
		System.out.println(p.getIncomeTable());
		
		System.out.println("-----------------");
	}
	@Test
	public void testFindAllPro() { //success
		List<Property> prolist = pri.findProTables();
		for (Property p: prolist) {
			System.out.println(p.getProId());
			System.out.println(p.getPropertyLoc());
			System.out.println(p.getPropertyName());
			System.out.println(p.getPropertyType());
			System.out.println(p.getEstimatedAmt());
			System.out.println(p.getIncomeTable());
			
			System.out.println("-----------------");
		}
	}
	

	@Test
	public void testLoanTrackerInsert() {//success
	LoanTracker lt=new LoanTracker();
	String str2="1996-08-15";
	 Date date2=Date.valueOf(str2);
	lt.setLoanapprovaldate(date2);
	lt.setAccNo(1524789365);
	lt.setLoanAppId(10006);
	ltr.addLoanTracker(lt);
	
	}
	
	@Test
	public void testLoanTrackerDelete() {//success
	ltr.removeLoanTracker(61);
	}
	@Test
	public void testLoanTrackerModify() {
	LoanTracker lt=new LoanTracker();
	//lt.setFinalId(802);
	String st="02-Mar-2020";
	 Date date2=Date.valueOf(st);
	lt.setLoanapprovaldate(date2);
	lt.setLoanAppId(10005);
	lt.setAccNo(952147823);
	
	ltr.modifyLoanTracker(lt);
	}
	
	@Test
	public void testLoanTrackerFindAll() {//success
	LoanTracker lt=new LoanTracker();
	List<LoanTracker> llist=ltr.findLoanTrackers();		
	
	for(LoanTracker l:llist) {
		System.out.println(l.getAccNo());
		System.out.println(l.getFinalId());
		System.out.println(l.getLoanAppId());
		System.out.println(l.getLoanapprovaldate());
		System.out.println(l.getDocTable());
		
	}
	}
}


