package com.example.homeloan;

import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.homeloan.layer2.Document;
import com.example.homeloan.layer2.UserRegistration;
import com.example.homeloan.layer3.DocumentRepo;
import com.example.homeloan.layer3.UserRegistrationRepo;

@SpringBootTest
public class DocTableTestCase {


	@Autowired
	DocumentRepo docRepo;
	
	@Autowired
	UserRegistrationRepo userRepo;
	
	@Test
	public void testInsertNewDocument() {//success
		Document doc = new Document();
		doc.setPanCard("Uploaded");
		doc.setVoterId("Submitted");
		doc.setSalaryslip("Uploaded");
		doc.setLoa("Completed");
		doc.setNoc("Submitted");
		doc.setAgreement("Submitted");
		UserRegistration user=userRepo.findUser(101);  
		doc.setUserRegistration(user);
		docRepo.addDocument(doc);
	}
	@Test
	public void testModifyDocument() {//success
		Document doc = new Document();
		UserRegistration user=userRepo.findUser(101);  
		docRepo.findDocument(122); 
		doc.setDocId(122);
		doc.setPanCard("Uploaded");
		doc.setVoterId("notsubmitted");
		doc.setSalaryslip("Uploaded");
		doc.setLoa("Completed");
		doc.setNoc("SUBMITTED");
		doc.setAgreement("Not Submitted");
		doc.setUserRegistration(user);
		docRepo.modifyDocument(doc);	
	}
	@Test
	public void testRemoveDocument() {//success//dbt
		docRepo.removeDocument(122);
		
	}
	@Test
	public void testFindDocument() {//success
		Document doc=docRepo.findDocument(703);
		System.out.println(doc.getDocId());
		System.out.println(doc.getPanCard());
		System.out.println(doc.getVoterId());
		System.out.println(doc.getSalaryslip());
		System.out.println(doc.getLoa());
		System.out.println(doc.getNoc());
		System.out.println(doc.getAgreement());
		System.out.println(doc.getUserRegistration().getUserId());
		System.out.println("-----------------");
	
	}
	@Test
	public void testFindAllDocument() {//success
		Set<Document> docSet = docRepo.findDocuments();
		for (Document doc: docSet) {
			System.out.println(doc.getDocId());
			System.out.println(doc.getPanCard());
			System.out.println(doc.getVoterId());
			System.out.println(doc.getSalaryslip());
			System.out.println(doc.getLoa());
			System.out.println(doc.getNoc());
			System.out.println(doc.getAgreement());
			System.out.println(doc.getUserRegistration().getUserId());
			System.out.println("-----------------");
		}
		
	}
}
