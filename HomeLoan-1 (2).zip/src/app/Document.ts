import { LoanTracker } from "./LoanTracker";

export class Document{
	docId:number|undefined;
    agreement:string|undefined;
    loa:string|undefined;
    noc:string|undefined;
    panCard:string|undefined;
    salaryslip:string|undefined;
    voterId:string|undefined;
    loanTracker:LoanTracker[]|undefined;
	
}

export class DocumentDTO{
	docId:number|undefined;
    agreement:string|undefined;
    loa:string|undefined;
    noc:string|undefined;
    panCard:string|undefined;
    salaryslip:string|undefined;
    voterId:string|undefined;
    userId:number|undefined;
}