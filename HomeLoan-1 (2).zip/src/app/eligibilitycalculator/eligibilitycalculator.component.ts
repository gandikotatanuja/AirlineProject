import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eligibilitycalculator',
  templateUrl: './eligibilitycalculator.component.html',
  styleUrls: ['./eligibilitycalculator.component.css']
})
export class EligibilitycalculatorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  income=0;
  roi=0;
  eligibility=0;


  Calculator()
  {
    this.eligibility = 60 * (this.roi * this.income)  
  }
}
