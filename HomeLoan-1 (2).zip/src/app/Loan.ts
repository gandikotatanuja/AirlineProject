export class Loan{
    loanId :number|undefined;
   interestRate:number |undefined;
   loanAmount:number|undefined;
   maxLoan:number | undefined;
   tenure : number|undefined;
   }

   export class LoanDTO{
    loanId :number|undefined;
   interestRate:number |undefined;
   loanAmount:number|undefined;
   maxLoan:number | undefined;
   tenure : number|undefined;
   proId:number|undefined;
   incomeId:number|undefined;
    userId:number|undefined;
   }