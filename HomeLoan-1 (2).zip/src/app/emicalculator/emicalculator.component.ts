import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emicalculator',
  templateUrl: './emicalculator.component.html',
  styleUrls: ['./emicalculator.component.css']
})
export class EmicalculatorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  amount=0;
  tenure=0;
  Rate=0;
  emi=0;
  r=0;
 
  Calculate()
  {
   // alert("calculate invoke");
   this.r=(this.Rate/12)/100;
  // alert(this.r);
   

     this.emi = this.amount*this.r*((Math.pow((1+this.r),(this.tenure))/((Math.pow((1+this.r),(this.tenure)))-1)));


  }
}
