import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StatusofuserComponent } from './statusofuser.component';

describe('StatusofuserComponent', () => {
  let component: StatusofuserComponent;
  let fixture: ComponentFixture<StatusofuserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StatusofuserComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StatusofuserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
