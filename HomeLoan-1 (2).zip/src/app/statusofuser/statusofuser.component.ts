import { Component, OnInit } from '@angular/core';
import { LoanTracker } from '../LoanTracker';
import { LoginserviceService } from '../loginservice.service';
import { UserRegister } from '../UserRegister';

@Component({
  selector: 'app-statusofuser',
  templateUrl: './statusofuser.component.html',
  styleUrls: ['./statusofuser.component.css']
})
export class StatusofuserComponent implements OnInit {

  constructor(private ccs:LoginserviceService) { }
  mydata: any  | undefined;
  
  user: UserRegister=new UserRegister();
  ngOnInit(): void {
    this.mydata = sessionStorage.getItem("MYUSER");
    this.user = JSON.parse(this.mydata);
  }
  dno=0;
  tempUser:  LoanTracker=new LoanTracker();
  findLoanTracker(dno: number){
   this.ccs.findLoanTrackerService(dno).subscribe((data: LoanTracker)=>{
     if (data!=null) 
     {this.tempUser=data;
     console.log(data);
     }
     else{
       alert('unable to featch');
     }
     })

}
}
