import { Component, OnInit } from '@angular/core';
import { LoginserviceService } from '../loginservice.service';
import { UserRegister } from '../UserRegister';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private ccs:LoginserviceService) { }

  ngOnInit(): void {
  }
  dno=0;
  p:number|undefined;
  myUser: UserRegister=new UserRegister();
  addUser(myUser:UserRegister){
    this.ccs.addUserService(myUser).subscribe((data)=>{
      if(data!=null){
        alert(data);
        //this.p=myUser.userId;
       // alert(myUser.userId);
        sessionStorage.setItem("your user id is",JSON.stringify(myUser));
      
      }
    },
      (err)=>{
        alert("some thing went wrong");
        console.log(err);
      })
}

}
