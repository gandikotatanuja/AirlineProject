import { Component, OnInit } from '@angular/core';
import { DocumentDTO } from '../Document';
import { LoginserviceService } from '../loginservice.service';

@Component({
  selector: 'app-document',
  templateUrl: './document.component.html',
  styleUrls: ['./document.component.css']
})
export class DocumentComponent implements OnInit {

  constructor(private ccs:LoginserviceService) { }

  ngOnInit(): void {
  }

  myDocument: DocumentDTO=new DocumentDTO();
  addDocument( myDocument:DocumentDTO){
    this.ccs.addDocumentService( myDocument).subscribe((data)=>{
      if(data!=null){
        //alert(this.  myDocument);
      //  sessionStorage.setItem("MYDOCUMENT",JSON.stringify(this.myDocument));
        console.log(this.myDocument);
        alert(data);
        //alert("adding is successful");
      }},
      (err)=>{
        alert("some thing went wrong");
        console.log(err);
      })
  }  

}
