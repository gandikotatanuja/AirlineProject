import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { ContactusComponent } from './contactus/contactus.component';
import { DocumentComponent } from './document/document.component';
import { EligibilitycalculatorComponent } from './eligibilitycalculator/eligibilitycalculator.component';
import { EmicalculatorComponent } from './emicalculator/emicalculator.component';
import { FaqComponent } from './faq/faq.component';
import { HomepageComponent } from './homepage/homepage.component';
import { IncomeComponent } from './income/income.component';
import { LoanComponent } from './loan/loan.component';
import { LoantrackerComponent } from './loantracker/loantracker.component';
import { LoginComponent } from './login/login.component';
import { MainpageComponent } from './mainpage/mainpage.component';
import { PropertyComponent } from './property/property.component';
import { RegisterComponent } from './register/register.component';
import { StatusofuserComponent } from './statusofuser/statusofuser.component';
import { ViewdetailsofusersComponent } from './viewdetailsofusers/viewdetailsofusers.component';
import { ViewusersComponent } from './viewusers/viewusers.component';

const routes: Routes = [
  { path:'',redirectTo:"profile",pathMatch:'full'},
  {path:"faq",component:FaqComponent},
  {path:"login",component:LoginComponent},
  {path:"register",component:RegisterComponent},
  {path:"loan",component:LoanComponent},
  {path:"loantracker",component:LoantrackerComponent},
  {path:"income",component:IncomeComponent},
  {path:"mainpage",component:MainpageComponent},
  {path:"contactus",component:ContactusComponent},
  {path:"property",component:PropertyComponent},
  {path:"homepage",component:HomepageComponent},
  {path:"adminhome",component:AdminhomeComponent},
  {path:"adminlogin",component:AdminloginComponent},
  {path:"viewusers",component:ViewusersComponent},
  {path:"viewdetails",component:ViewdetailsofusersComponent},
  {path:"eligible",component:EligibilitycalculatorComponent},
  {path:"emi",component:EmicalculatorComponent},
  {path:"document",component:DocumentComponent},
  {path:"status",component:StatusofuserComponent},
  {path:"loantracker",component:LoantrackerComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
