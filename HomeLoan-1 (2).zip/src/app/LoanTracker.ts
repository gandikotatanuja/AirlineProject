export class LoanTracker{
    finalId : number|undefined;
     accNo : number|undefined;;
    loanAppId : number|undefined;;
    loanApprovalDate :Date|undefined ;
}
export class LoanTrackerDTO{
    finalId : number|undefined;
     accNo : number|undefined;;
    loanAppId : number|undefined;
    loanApprovalDate :Date|undefined ;
     docId:number|undefined;
}