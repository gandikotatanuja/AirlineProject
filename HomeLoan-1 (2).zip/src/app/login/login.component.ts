import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginserviceService } from '../loginservice.service';
import { UserRegister } from '../UserRegister';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private ccs:LoginserviceService,private router: Router) { }

  ngOnInit(): void {
  }
  tempUser:  UserRegister =new UserRegister();
  findUserByUserId(dno: number){
   this.ccs.findUserByUserId(dno).subscribe((data: UserRegister)=>{
     if (data!=null) 
     {
       this.tempUser=data;
     console.log(data);
     }
     else{
       alert('unable to fetch');
     }
     })
}


// user: any;
   tempUser1:  UserRegister =new UserRegister();
  // userSet:userValidate=new userValidate();
   loginValidate() {
    this.ccs.findUserByUserIDPasswordService(this.tempUser1).subscribe((data: UserRegister)=>{
      if (data!=null) 
      {
       this.tempUser1=data;
      console.log(data);
      sessionStorage.setItem("MYUSER",JSON.stringify(this.tempUser1));
     this.router.navigate(['/homepage']);
      alert('login succesfull');
      }
      else{
      this.router.navigate(['/login']);
      alert("Invalid username and password");
      }
      })
}
}
