import { Component, OnInit } from '@angular/core';
import { Income } from '../Income';
import { LoginserviceService } from '../loginservice.service';
import { PropertyDTO } from '../Property';
import { UserRegister } from '../UserRegister';

@Component({
  selector: 'app-property',
  templateUrl: './property.component.html',
  styleUrls: ['./property.component.css']
})
export class PropertyComponent implements OnInit {

  mydata: any  | undefined;
  mydata1: any  | undefined;
  user: UserRegister=new UserRegister();
  income:Income=new Income();
  constructor(private ccs:LoginserviceService ) { }

  ngOnInit(): void {
    this.mydata = sessionStorage.getItem("MYUSER");
    this.user = JSON.parse(this.mydata);
    this.mydata1=sessionStorage.getItem("MYINCOME");
    this.income = JSON.parse(this.mydata1);
  }
  myProperty: PropertyDTO=new PropertyDTO();
  addProperty( myProperty:PropertyDTO){
    this.ccs.addPropertyService( myProperty).subscribe((data)=>{
      if(data!=null){
        
        sessionStorage.setItem("MYPROPERTY",JSON.stringify(this.myProperty));
        alert(data);
      }},
      (err)=>{
        alert("some thing went wrong");
        console.log(err);
      })
  }  

}
