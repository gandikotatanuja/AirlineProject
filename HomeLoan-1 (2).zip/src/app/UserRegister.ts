import { Income } from "./Income";

export class UserRegister{
    userId:number |undefined;
    address:string |undefined;
    adharNo:number|undefined;
    confirmPassword:String|undefined;
    dob:Date |undefined;
    fname:string |undefined;
    gender: string|undefined;
    lname: string |undefined;
    mailid:string|undefined ;
    mname:string|undefined;
    nationality:string |undefined;
    panNo:string |undefined;
    password:string |undefined;
    phoneno:number |undefined;
    incomeSet:Income[]|undefined;
    DocumentSet:Document[]|undefined;
      
    }
    
    export class UserValidate
    {
        userId:number |undefined;
        password:string |undefined;
    }