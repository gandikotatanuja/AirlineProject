import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewdetailsofusersComponent } from './viewdetailsofusers.component';

describe('ViewdetailsofusersComponent', () => {
  let component: ViewdetailsofusersComponent;
  let fixture: ComponentFixture<ViewdetailsofusersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewdetailsofusersComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewdetailsofusersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
