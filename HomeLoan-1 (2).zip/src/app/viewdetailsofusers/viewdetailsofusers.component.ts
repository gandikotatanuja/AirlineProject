import { Component, OnInit } from '@angular/core';
import { Income } from '../Income';
import { LoginserviceService } from '../loginservice.service';
import { UserRegister } from '../UserRegister';

@Component({
  selector: 'app-viewdetailsofusers',
  templateUrl: './viewdetailsofusers.component.html',
  styleUrls: ['./viewdetailsofusers.component.css']
})
export class ViewdetailsofusersComponent implements OnInit {

  constructor(private ccs:LoginserviceService ) { }

  ngOnInit(): void {
  }
  dno : number=0;
  tempUser:  Income[] |undefined;
  findIncomeByUserId(dno: number){
   this.ccs.findIncomeByUserIdService(dno).subscribe((data:  Income[])=>{
     if (data!=null) 
     {this.tempUser=data;
     console.log(data);
     }
     else{
       alert('unable to featch');
     }
     })
}


}
