import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { ViewusersComponent } from './viewusers/viewusers.component';
import { DocumentComponent } from './document/document.component';
import { LoantrackerComponent } from './loantracker/loantracker.component';
import { IncomeComponent } from './income/income.component';
import { PropertyComponent } from './property/property.component';
import { LoanComponent } from './loan/loan.component';
import { MainpageComponent } from './mainpage/mainpage.component';
import { HomepageComponent } from './homepage/homepage.component';
import { FaqComponent } from './faq/faq.component';
import { ContactusComponent } from './contactus/contactus.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ViewdetailsofusersComponent } from './viewdetailsofusers/viewdetailsofusers.component';
import { StatusofuserComponent } from './statusofuser/statusofuser.component';
import { FormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { LoginserviceService } from './loginservice.service';
import { EligibilitycalculatorComponent } from './eligibilitycalculator/eligibilitycalculator.component';
import { EmicalculatorComponent } from './emicalculator/emicalculator.component';

@NgModule({
  declarations: [
    AppComponent,
    AdminhomeComponent,
    AdminloginComponent,
    ViewusersComponent,
    DocumentComponent,
    LoantrackerComponent,
    IncomeComponent,
    PropertyComponent,
    LoanComponent,
    MainpageComponent,
    HomepageComponent,
    FaqComponent,
    ContactusComponent,
    LoginComponent,
    RegisterComponent,
    ViewdetailsofusersComponent,
    StatusofuserComponent,
    EligibilitycalculatorComponent,
    EmicalculatorComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [LoginserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
