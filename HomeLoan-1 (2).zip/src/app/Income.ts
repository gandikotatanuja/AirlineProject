import { Property } from "./Property";

export class Income{
    incomeId:number|undefined;
	employerName:string|undefined;
	organizationType:string|undefined;
    retirementAge:number|undefined;
    typeOfEmp:string|undefined;
    property:Property[]|undefined;
}

export class IncomeDTO{
    incomeId:number|undefined;
	employerName:string|undefined;
	organizationType:string|undefined;
    retirementAge:number|undefined;
    typeOfEmp:string|undefined;
    userId:number|undefined;
    
}