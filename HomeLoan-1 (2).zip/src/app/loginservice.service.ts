import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { DocumentDTO } from './Document';
import { Income, IncomeDTO } from './Income';
import { LoanDTO } from './Loan';
import { LoanTracker, LoanTrackerDTO } from './LoanTracker';
import { PropertyDTO } from './Property';
import { UserRegister } from './UserRegister';


@Injectable({
  providedIn: 'root'
})
export class LoginserviceService {

  
  constructor(private myHttp:HttpClient) { }
  
addUserService(myUser: UserRegister){
    return this.myHttp.post("http://localhost:8080/addUser",myUser,{responseType:'text'});
 }
 findUserByUserId(dno: number): Observable<UserRegister> {
  return this.myHttp.get<UserRegister>("http://localhost:8080/getUser/"+dno);  
}
findUserByUserIDPasswordService(user: UserRegister): Observable<UserRegister> {
  return this.myHttp.post<UserRegister>("http://localhost:8080/loginUser",user);  
}
addIncomeService(myIncome: IncomeDTO){
  return this.myHttp.post("http://localhost:8080/addIncome",myIncome,{responseType:'text'});
}
addPropertyService(myProperty: PropertyDTO){
  return this.myHttp.post("http://localhost:8080/addProperty",myProperty,{responseType:'text'});
}
addLoanService(myloan: LoanDTO){
  return this.myHttp.post("http://localhost:8080/addLoan",myloan,{responseType:'text'});
}
findUsersService(): Observable<UserRegister[]> {
  return this.myHttp.get<UserRegister[]>("http://localhost:8080/getUsers");
   
}
addDocumentService(myDocument: DocumentDTO){
  return this.myHttp.post("http://localhost:8080/addDoc",myDocument,{responseType:'text'});
}
findLoanTrackerService(dno: number): Observable<LoanTracker> {
  return this.myHttp.get<LoanTracker>("http://localhost:8080/getLoanTracker/"+dno);
   
}
  addLoanTrackerService(loanTracker:LoanTrackerDTO){
    return this.myHttp.post("http://localhost:8080/addLoanTracker",loanTracker,{responseType:'text'});
  }
  findIncomesService(): Observable<Income[]> {
    return this.myHttp.get<Income[]>("http://localhost:8080/getincomes");
     
  }
  findIncomeByUserIdService(dno: number): Observable<Income[]> {
    return this.myHttp.get<Income[]>("http://localhost:8080/IncomeByUserId/"+dno);
     
  }
}
