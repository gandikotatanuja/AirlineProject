import { Component, OnInit } from '@angular/core';
import { Income, IncomeDTO } from '../Income';
import { LoginserviceService } from '../loginservice.service';
import { UserRegister } from '../UserRegister';

@Component({
  selector: 'app-income',
  templateUrl: './income.component.html',
  styleUrls: ['./income.component.css']
})
export class IncomeComponent implements OnInit {

  mydata: any  | undefined;
  
  user: UserRegister=new UserRegister();
  constructor(private ccs:LoginserviceService ) { }

  ngOnInit(): void {
    this.mydata = sessionStorage.getItem("MYUSER");
    this.user = JSON.parse(this.mydata);
    }
 
    myIncome: IncomeDTO=new IncomeDTO();
    addIncome(myIncome:IncomeDTO){
      this.ccs.addIncomeService(myIncome).subscribe((data)=>{
        if(data!=null){
         // alert(this. myIncome);

         // sessionStorage.setItem("MYINCOME",JSON.stringify(this.myIncome));
          alert(data);
         
        }},
        (err)=>{
          alert("some thing went wrong");
          console.log(err);
        })
    }  
    
    

}
