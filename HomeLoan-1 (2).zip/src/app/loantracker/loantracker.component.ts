import { Component, OnInit } from '@angular/core';
import { LoanTrackerDTO } from '../LoanTracker';
import { LoginserviceService } from '../loginservice.service';


@Component({
  selector: 'app-loantracker',
  templateUrl: './loantracker.component.html',
  styleUrls: ['./loantracker.component.css']
})
export class LoantrackerComponent implements OnInit {

  constructor(private ccs:LoginserviceService ) { }

  ngOnInit(): void {
  }
  loanTracker: LoanTrackerDTO=new  LoanTrackerDTO();
  addLoanTracker(  loanTracker: LoanTrackerDTO){
    this.ccs.addLoanTrackerService( loanTracker).subscribe((data)=>{
      if(data!=null){
       // alert(this. loanTracker);
        sessionStorage.setItem("MYPROPERTY",JSON.stringify(this.loanTracker));
        alert(data);
      }},
      (err)=>{
        alert("some thing went wrong");
        console.log(err);
      })
  }  

}
