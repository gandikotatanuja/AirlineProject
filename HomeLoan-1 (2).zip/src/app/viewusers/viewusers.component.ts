import { Component, OnInit } from '@angular/core';
import { Income } from '../Income';
import { LoginserviceService } from '../loginservice.service';
import { UserRegister } from '../UserRegister';

@Component({
  selector: 'app-viewusers',
  templateUrl: './viewusers.component.html',
  styleUrls: ['./viewusers.component.css']
})
export class ViewusersComponent implements OnInit {

  constructor(private ccs:LoginserviceService ) { }

  ngOnInit(): void {
  }
  tempUser:  UserRegister[] |undefined;
  findUsers(){
   this.ccs.findUsersService().subscribe((data: UserRegister[])=>{
     if (data!=null) 
     {this.tempUser=data;
     console.log(data);
     }
     else{
       alert('unable to featch');
     }
     })

}
 
}
