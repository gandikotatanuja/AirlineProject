import { Component, OnInit } from '@angular/core';
import { Income } from '../Income';
import { LoanDTO } from '../Loan';
import { LoginserviceService } from '../loginservice.service';
import { Property } from '../Property';
import { UserRegister } from '../UserRegister';

@Component({
  selector: 'app-loan',
  templateUrl: './loan.component.html',
  styleUrls: ['./loan.component.css']
})
export class LoanComponent implements OnInit {

  mydata: any  | undefined;
  mydata1: any  | undefined;
  mydata2: any  | undefined;
  user: UserRegister=new UserRegister();
  income:Income=new Income();
  property:Property=new Property();
  constructor(private ccs:LoginserviceService ) { }

  ngOnInit(): void {
    this.mydata = sessionStorage.getItem("MYUSER");
    this.user = JSON.parse(this.mydata);
    this.mydata1=sessionStorage.getItem("MYINCOME");
    this.income = JSON.parse(this.mydata1);
    this.mydata2=sessionStorage.getItem("MYPROPERTY");
    this.property = JSON.parse(this.mydata2);
  }
  myloan: LoanDTO=new LoanDTO();
  addLoan(myloan:LoanDTO){
    this.ccs.addLoanService(myloan).subscribe((data)=>{
      if(data!=null){
        //alert(this. myloan);
        sessionStorage.setItem("MYLOAN",JSON.stringify(this.myloan));
        alert(data);
       // alert("adding is successful");
      }},
      (err)=>{
        alert("some thing went wrong");
        console.log(err);
      })
  }  

}
