import { Component, OnInit } from '@angular/core';
import { UserRegister } from '../UserRegister';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {

  constructor() { }

  mydata: any  | undefined;
  
  user: UserRegister=new UserRegister();

  ngOnInit(): void {

    this.mydata = sessionStorage.getItem("MYUSER");
    this.user = JSON.parse(this.mydata);

  }
}
