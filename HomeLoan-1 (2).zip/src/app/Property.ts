import { Loan } from "./Loan";

export class Property{
    proId:number|undefined;
    estimatedAmt:number|undefined;
    propertyLoc:string|undefined;
    propertyName:string|undefined;
    propertyType:string|undefined;
    loan:Loan[] |undefined;
}
export class PropertyDTO{
    proId:number|undefined;
    estimatedAmt:number|undefined;
    propertyLoc:string|undefined;
    propertyName:string|undefined;
    propertyType:string|undefined;
    incomeId:number|undefined;
    userId:number|undefined;
}