import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CustomerCareService {

  constructor() { }
  phoneCalls()
  {
    alert('calling ');
  }
  registerComplaint()
  {
    alert('registered a complaint');
  }
}
