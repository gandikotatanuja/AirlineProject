import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { AccountsummaryComponent } from './account-summary/accountsummary/accountsummary.component';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BankStatementModule } from './bank-statement/bank-statement.module';
import { CurrencyConverterService } from './currency-converter.service';
import { FundTransferModule } from './fund-transfer/fund-transfer.module';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import {HttpClientModule} from '@angular/common/http'
import {HttpClient} from '@angular/common/http'
import { CustomerCareService } from './CustomerCareService/customer-care.service';
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    AccountsummaryComponent
   
    //we are declaring that appcomponent is one of the component of module
  ],
  imports: [
    BrowserModule,
    FormsModule,// for browser module to avail
    AppRoutingModule,// for routin of many pages during navigation(routing from one view to another view)
    BankStatementModule,
    FundTransferModule,
    HttpClientModule

  ],
  providers: [CurrencyConverterService,CustomerCareService],//coming session we will provide service
  bootstrap: [AppComponent]// this would be launched as a bootstap
})
export class AppModule { } //we are declaring that our app module is angular module now with @ngModule
