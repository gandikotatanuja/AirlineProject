import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MonthlyStatementComponent } from './monthly-statement/monthly-statement.component';
import { BankstatementserviceService } from './bankstatementservice.service';




@NgModule({
  declarations: [
    MonthlyStatementComponent
  ],
  imports: [
    CommonModule
  ],
  exports:[
    MonthlyStatementComponent//its is now avaiabale to outside
  ],
  providers:[BankstatementserviceService]
})
export class BankStatementModule { }
