import { TestBed } from '@angular/core/testing';

import { BankstatementserviceService } from './bankstatementservice.service';

describe('BankstatementserviceService', () => {
  let service: BankstatementserviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BankstatementserviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
