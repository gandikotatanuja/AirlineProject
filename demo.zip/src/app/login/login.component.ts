import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { CurrencyConverterService } from '../currency-converter.service';
import { CustomerCareService } from '../CustomerCareService/customer-care.service';
import { Department } from './Department';
import { employee } from './Employee';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
     
     prompt1='Enter USername';
     prompt2='Enter Password';
     uname='tanuja';
     upass='tanu123';
     dno =0;
     isLoggedIn=true;
     Signin:boolean=true
     Signout:boolean=false
     mySignInFunction()
     {
       this.Signin=!this.Signin;
       if(this.Signin)
       {
       alert('signout is clicked');
     }
     this.Signout=!this.Signout;
       if(this.Signout)
       {
       alert('signin is clicked');
     }
    }
    myBirthDate=new Date();
    ShowMe:boolean=false
    ShowMe1:boolean=false
    ShowMe2:boolean=false
    ShowMe3:boolean=false
     toogleTag()
     {
       this.ShowMe=!this.ShowMe;
     }
     toogleTag1()
     {
       this.ShowMe1=!this.ShowMe1;
     }
     toogleTag2()
     {
       this.ShowMe2=!this.ShowMe2;
     }
     toogleTag3()
     {
       this.ShowMe3=!this.ShowMe3;
     }
    
     allDepts=["testing","it","accounting","coding","marketing"];//array of strings
      dept: Department= new Department();//its an object
  /*    deptAry: Department[] = [
        {
          "departmentNumber": 30,
          "departmentName": "SALES",
          "departmentLocation": "CHICAGO",
          "empSet": [
              {
                  "employeeNumber": 7698,
                  "employeeName": "BLAKE",
                  "employeeJob": "MANAGER",
                  "employeeManager": 7839,
                  "employeeHireDate": new Date("1981-05-01"),
                  "employeeSalary": 2850.0,
                  "employeeCommission": 100,
                  "custList": []
              },
              {
                  "employeeNumber": 7654,
                  "employeeName": "MARTIN",
                  "employeeJob": "SALESMAN",
                  "employeeManager": 7698,
                  "employeeHireDate": new Date("1981-09-28"),
                  "employeeSalary": 1250.0,
                  "employeeCommission": 1400.0,
                  "custList": [
                      {
                          "customerid": 102,
                          "name": "VOLLYRITE",
                          "city": "BURLINGAME",
                          "creditlimit": 7000.0,
                          "ordList": [
                              {
                                  "ordid": 602,
                                  "oderDate":new Date( "1986-06-05"),
                                  "commplan": "B",
                                  "shipDate":new Date( "1986-06-20"),
                                  "total": 56
                              },
                              {
                                  "ordid": 611,
                                  "oderDate": new Date("1987-01-11"),
                                  "commplan": "B",
                                  "shipDate": new Date("1987-01-11"),
                                  "total": 45
                              },
                              {
                                  "ordid": 618,
                                  "oderDate": new Date("1987-02-15"),
                                  "commplan": "A",
                                  "shipDate": new Date("1987-03-06"),
                                  "total": 3510
                              },
                              {
                                  "ordid": 614,
                                  "oderDate":new Date( "1987-02-01"),
                                  "commplan": "A",
                                  "shipDate": new Date("1987-02-05"),
                                  "total": 23940
                              },
                              {
                                  "ordid": 603,
                                  "oderDate":new Date( "1986-06-05"),
                                  "commplan": "A",
                                  "shipDate": new Date("1986-06-05"),
                                  "total": 224
                              }
                          ]
                      }
                  ]
              },
              {
                  "employeeNumber": 7844,
                  "employeeName": "TURNER",
                  "employeeJob": "SALESMAN",
                  "employeeManager": 7698,
                  "employeeHireDate": new Date("1981-09-08"),
                  "employeeSalary": 1500.0,
                  "employeeCommission": 0.0,
                  "custList": [
                      {
                          "customerid": 108,
                          "name": "NORTH WOOD HEALTH AND FITNESS SUPPLY CENTER",
                          "city": "HIBBING",
                          "creditlimit": 8000.0,
                          "ordList": [
                              {
                                  "ordid": 613,
                                  "oderDate":new Date( "1987-02-01"),
                                  "commplan": "A",
                                  "shipDate": new Date("1987-02-01"),
                                  "total": 6400
                              }
                          ]
                      },
                      {
                          "customerid": 105,
                          "name": "K + T SPORTS",
                          "city": "SANTA CLRA",
                          "creditlimit": 5000.0,
                          "ordList": [
                              {
                                  "ordid": 617,
                                  "oderDate": new Date("1987-02-05"),
                                  "commplan": "A",
                                  "shipDate": new Date("1987-03-03"),
                                  "total": 46370
                              }
                          ]
                      },
                      {
                          "customerid": 100,
                          "name": "JOCKSPORTS",
                          "city": "VIEWRIDGE",
                          "creditlimit": 5000.0,
                          "ordList": [
                              {
                                  "ordid": 606,
                                  "oderDate":new Date( "1986-07-14"),
                                  "commplan": "A",
                                  "shipDate": new Date("1986-07-30"),
                                  "total": 3
                              },
                              {
                                  "ordid": 620,
                                  "oderDate": new Date("1987-03-12"),
                                  "commplan":"A",
                                  "shipDate": new Date("1987-03-12"),
                                  "total": 4450
                              },
                              {
                                  "ordid": 609,
                                  "oderDate":new Date( "1986-08-01"),
                                  "commplan": "B",
                                  "shipDate": new Date("1986-08-15"),
                                  "total": 97
                              },
                              {
                                  "ordid": 621,
                                  "oderDate": new Date("1987-03-15"),
                                  "commplan": "A",
                                  "shipDate":new Date( "1987-01-01"),
                                  "total": 730
                              }
                          ]
                      }
                  ]
              },
              {
                  "employeeNumber": 7521,
                  "employeeName": "WARD",
                  "employeeJob": "SALESMAN",
                  "employeeManager": 7698,
                  "employeeHireDate": new Date("1981-02-22"),
                  "employeeSalary": 1250.0,
                  "employeeCommission": 500.0,
                  "custList": [
                      {
                          "customerid": 106,
                          "name": "SHAPE UP",
                          "city": "PLAO ALTO",
                          "creditlimit": 6000.0,
                          "ordList": [
                              {
                                  "ordid": 605,
                                  "oderDate": new Date("1986-07-14"),
                                  "commplan": "A",
                                  "shipDate": new Date("1986-07-30"),
                                  "total": 8324
                              },
                              {
                                  "ordid": 604,
                                  "oderDate": new Date("1986-06-15"),
                                  "commplan": "A",
                                  "shipDate":new Date( "1986-06-30"),
                                  "total": 698
                              },
                              {
                                  "ordid": 601,
                                  "oderDate": new Date("1986-05-01"),
                                  "commplan": "A",
                                  "shipDate": new Date("1986-05-30"),
                                  "total": 2
                              }
                          ]
                      },
                      {
                          "customerid": 101,
                          "name": "TKB SPORT SHOP",
                          "city": "REDWOOD CITY",
                          "creditlimit": 10000.0,
                          "ordList": [
                              {
                                  "ordid": 610,
                                  "oderDate": new Date("1987-01-07"),
                                  "commplan": "A",
                                  "shipDate":new Date( "1987-01-08"),
                                  "total": 101
                              }
                          ]
                      },
                      {
                          "customerid": 103,
                          "name": "JUST TENNIS",
                          "city": "BURLINGAME",
                          "creditlimit": 3000.0,
                          "ordList": [
                              {
                                  "ordid": 616,
                                  "oderDate": new Date("1987-02-03"),
                                  "commplan": "A",
                                  "shipDate": new Date("1987-02-10"),
                                  "total": 764
                              }
                          ]
                      }
                  ]
              },
              {
                  "employeeNumber": 7900,
                  "employeeName": "JAMES",
                  "employeeJob": "CLERK",
                  "employeeManager": 7698,
                  "employeeHireDate": new Date("1981-12-03"),
                  "employeeSalary": 950.0,
                  "employeeCommission": 100,
                  "custList": []
              },
              {
                  "employeeNumber": 7499,
                  "employeeName": "ALLEN",
                  "employeeJob": "SALESMAN",
                  "employeeManager": 7698,
                  "employeeHireDate":new Date("1981-02-20"),
                  "employeeSalary": 1600.0,
                  "employeeCommission": 300.0,
                  "custList": [
                      {
                          "customerid": 104,
                          "name": "EVERY MOUNTAIN",
                          "city": "SURRY RD",
                          "creditlimit": 10000.0,
                          "ordList": [
                              {
                                  "ordid": 619,
                                  "oderDate": new Date("1987-02-22"),
                                  "commplan": "A",
                                  "shipDate":new Date( "1987-02-04"),
                                  "total": 1260
                              },
                              {
                                  "ordid": 607,
                                  "oderDate":new Date( "1986-07-18"),
                                  "commplan": "C",
                                  "shipDate": new Date("1986-07-18"),
                                  "total": 5
                              },
                              {
                                  "ordid": 612,
                                  "oderDate":new Date("1987-01-15"),
                                  "commplan": "C",
                                  "shipDate": new Date("1987-01-20"),
                                  "total": 5860
                              },
                              {
                                  "ordid": 608,
                                  "oderDate":new Date( "1986-07-25"),
                                  "commplan": "C",
                                  "shipDate": new Date("1986-07-25"),
                                  "total": 35
                              }
                          ]
                      },
                      {
                          "customerid": 107,
                          "name": "WOMEN SPORTS",
                          "city": "SUNNY VALLE",
                          "creditlimit": 10000.0,
                          "ordList": [
                              {
                                  "ordid": 615,
                                  "oderDate": new Date("1987-02-01"),
                                  "commplan": "A",
                                  "shipDate": new Date("1987-02-06"),
                                  "total": 710
                              }
                          ]
                      }
                  ]
              },
              {
                  "employeeNumber": 5423,
                  "employeeName": "C1",
                  "employeeJob": "New1",
                  "employeeManager": 7900,
                  "employeeHireDate": new Date("2019-02-13"),
                  "employeeSalary": 1150.0,
                  "employeeCommission": 100.0,
                  "custList": []
              }
          ]
      }
      ];
    */
     

  ngOnInit(): void {
    this.dept.departmentNumber=10;
    this.dept.departmentName='accounting';
    this.dept.departmentLocation='newyork';
  //  console.log(this.deptAry);
  }
  constructor(private ccs: CurrencyConverterService,private custCare:CustomerCareService,private myhttp:HttpClient){//without this the object is not injected
}
  invokeConvert() {
  this.ccs.convert();
  this.ccs.connectMarketPlace();
  this.ccs.connectcurrencyServer();
  this.ccs.updateCurrencies();
  this.custCare.phoneCalls();
  this.custCare.registerComplaint();
  
}
tempDept: Department= new Department();
  findDepartmentByDeptno(dno: number){
      this.ccs.findDepartmentByDeptnoService(dno).subscribe((data)=>{
        if (data!=null) 
        {this.tempDept=data;}
        else{
          alert('unable to featch');
        }
        })
  }
}
