import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewallpayee',
  templateUrl: './viewallpayee.component.html',
  styleUrls: ['./viewallpayee.component.css']
})
export class ViewallpayeeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
