import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewallpayeeComponent } from './viewallpayee.component';

describe('ViewallpayeeComponent', () => {
  let component: ViewallpayeeComponent;
  let fixture: ComponentFixture<ViewallpayeeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewallpayeeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewallpayeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
