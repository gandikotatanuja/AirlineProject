import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewpayee',
  templateUrl: './viewpayee.component.html',
  styleUrls: ['./viewpayee.component.css']
})
export class ViewpayeeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
