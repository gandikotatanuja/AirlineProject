import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewpayeeComponent } from './viewpayee.component';

describe('ViewpayeeComponent', () => {
  let component: ViewpayeeComponent;
  let fixture: ComponentFixture<ViewpayeeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewpayeeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewpayeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
