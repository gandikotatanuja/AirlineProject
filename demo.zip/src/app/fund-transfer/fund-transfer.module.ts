import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddPayeeComponent } from './add-payee/add-payee.component';
import { ViewpayeeComponent } from './viewpayee/viewpayee.component';
import { DeletewpayeeComponent } from './deletewpayee/deletewpayee.component';
import { ViewallpayeeComponent } from './viewallpayee/viewallpayee.component';
import { PayeeserviceService } from './payeeservice.service';



@NgModule({
  declarations: [
    AddPayeeComponent,
    ViewpayeeComponent,
    DeletewpayeeComponent,
    ViewallpayeeComponent
  ],
  imports: [
    CommonModule
  ],
  exports:[
    AddPayeeComponent,
    ViewpayeeComponent,
    DeletewpayeeComponent,
    ViewallpayeeComponent
  ],
  providers:[PayeeserviceService]
})
export class FundTransferModule { }
