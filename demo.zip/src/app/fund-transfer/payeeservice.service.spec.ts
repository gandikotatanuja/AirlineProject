import { TestBed } from '@angular/core/testing';

import { PayeeserviceService } from './payeeservice.service';

describe('PayeeserviceService', () => {
  let service: PayeeserviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PayeeserviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
