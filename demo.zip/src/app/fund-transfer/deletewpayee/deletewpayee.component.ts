import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deletewpayee',
  templateUrl: './deletewpayee.component.html',
  styleUrls: ['./deletewpayee.component.css']
})
export class DeletewpayeeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
