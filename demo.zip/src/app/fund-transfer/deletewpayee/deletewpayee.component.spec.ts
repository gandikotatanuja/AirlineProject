import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeletewpayeeComponent } from './deletewpayee.component';

describe('DeletewpayeeComponent', () => {
  let component: DeletewpayeeComponent;
  let fixture: ComponentFixture<DeletewpayeeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeletewpayeeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeletewpayeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
