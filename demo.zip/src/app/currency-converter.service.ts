import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Department } from './login/Department';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CurrencyConverterService {
  constructor(private myHttp: HttpClient) {}
    convert()
    {
      alert('currency converter invoked');
    }
    connectcurrencyServer()
    {
      alert('connectcurrencyServer invoked');
    }
    connectMarketPlace()
    {
      alert('connectMarketPlace invoked');
    }
    updateCurrencies()
    {
      alert('updateCurrencies invoked');
    }
    findDepartmentByDeptnoService(dno: number): Observable<Department> {
      return this.myHttp.get<Department>("http://localhost:8080/getDept/"+dno);
       
  }
}


