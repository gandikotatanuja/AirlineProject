import { TestBed } from '@angular/core/testing';

import { AccountsummaryserviceService } from './accountsummaryservice.service';

describe('AccountsummaryserviceService', () => {
  let service: AccountsummaryserviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AccountsummaryserviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
