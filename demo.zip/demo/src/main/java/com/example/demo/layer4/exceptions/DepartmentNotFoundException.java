package com.example.demo.layer4.exceptions;



@SuppressWarnings("serial")
public class DepartmentNotFoundException extends Throwable{
	public DepartmentNotFoundException(String msg) {
		super(msg);
	}
}
