package com.example.demo.layer2;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity(name="ord")
public class Order {
@Id
@Column(name="ORDID")
	private int ordid;
@Column(name="ORDERDATE")
private Date oderDate;
@Column(name="COMMPLAN",length = 1)
private Character commplan;
@Column(name="SHIPDATE")
private Date shipDate;
@Column(name="TOTAL")
private int total;

@ManyToOne
@JoinColumn(name="CUSTID")
private Customer2 cust;

public Order() {
	super();
     System.out.println("ord cont() called....");
}

public int getOrdid() {
	return ordid;
}

public void setOrdid(int ordid) {
	this.ordid = ordid;
}

public Date getOderDate() {
	return oderDate;
}

public void setOderDate(Date oderDate) {
	this.oderDate = oderDate;
}

public Character getCommplan() {
	return commplan;
}

public void setCommplan(Character commplan) {
	this.commplan = commplan;
}

public Date getShipDate() {
	return shipDate;
}

public void setShipDate(Date shipDate) {
	this.shipDate = shipDate;
}

public int getTotal() {
	return total;
}

public void setTotal(int total) {
	this.total = total;
}
@JsonIgnore
public Customer2 getCust() {
	return cust;
}

public void setCust(Customer2 cust) {
	this.cust = cust;
}

}

